import UIKit

// スクロール＋縦並びの土台
class ScrollStackViewController: UIViewController {
let scroll = UIScrollView()
let stack = UIStackView()
override func viewDidLoad() {
super.viewDidLoad()
view.backgroundColor = UIColor(red: 0.08, green: 0.22, blue: 0.14, alpha: 1)
scroll.translatesAutoresizingMaskIntoConstraints = false
view.addSubview(scroll)
stack.axis = .vertical
stack.spacing = 12
stack.translatesAutoresizingMaskIntoConstraints = false
scroll.addSubview(stack)
NSLayoutConstraint.activate([
scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
scroll.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
stack.topAnchor.constraint(equalTo: scroll.topAnchor, constant: 14),
stack.bottomAnchor.constraint(equalTo: scroll.bottomAnchor, constant: -14),
stack.leadingAnchor.constraint(equalTo: scroll.leadingAnchor, constant: 14),
stack.trailingAnchor.constraint(equalTo: scroll.trailingAnchor, constant: -14),
stack.widthAnchor.constraint(equalTo: scroll.widthAnchor, constant: -28),
])
}
}

// MARK: - テーマ＆ショップ
final class ThemeShopViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
rebuild()
}
private func rebuild() {
stack.arrangedSubviews.forEach { $0.removeFromSuperview()}
stack.addArrangedSubview(makeLabel("🪙 コイン：\(DataStore.shared.coins)", size: 17, bold: true, color:.yellow))
stack.addArrangedSubview(makeLabel("テーマを変えると、対戦画面の色とカードの背中の絵が変わります。", size: 13))
for t in allThemes {
let owned = DataStore.shared.ownedThemes.contains(t.id)
let using = DataStore.shared.selectedTheme == t.id
let row = UIView()
row.backgroundColor = UIColor.black.withAlphaComponent(0.30)
row.layer.cornerRadius = 12
let inner = UIStackView()
inner.axis = .vertical
inner.spacing = 6
inner.translatesAutoresizingMaskIntoConstraints = false
row.addSubview(inner)
NSLayoutConstraint.activate([
inner.topAnchor.constraint(equalTo: row.topAnchor, constant: 10),
inner.bottomAnchor.constraint(equalTo: row.bottomAnchor, constant: -10),
inner.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 12),
inner.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -12),
])
inner.addArrangedSubview(makeLabel("\(t.backEmoji) \(t.name)　\(t.detail)", size: 15, bold: true))
if using {
inner.addArrangedSubview(makeLabel("✅ 使用中", size: 14, color:.yellow))
} else if owned {
let b = makeButton("このテーマにする", bg: UIColor(red: 0.10, green: 0.55, blue: 0.30, alpha: 1))
b.addAction(UIAction { _ in
DataStore.shared.selectedTheme = t.id
SoundManager.shared.buy()
self.rebuild()
}, for:.touchUpInside)
inner.addArrangedSubview(b)
} else if t.premiumYen > 0 {
let b = makeButton("✨ プレミアム ¥\(t.premiumYen)（お試しで解放）", bg: UIColor(red: 0.55, green: 0.25, blue: 0.75, alpha: 1))
b.addAction(UIAction { _ in
let nav = UINavigationController(rootViewController: TrialStoreViewController())
self.present(nav, animated: true)
}, for:.touchUpInside)
inner.addArrangedSubview(b)
} else {
let b = makeButton("🪙 \(t.coinPrice) コインで買う", bg: UIColor(red: 0.85, green: 0.55, blue: 0.10, alpha: 1))
b.addAction(UIAction { _ in
if DataStore.shared.coins >= t.coinPrice {
DataStore.shared.coins -= t.coinPrice
DataStore.shared.ownedThemes.append(t.id)
SoundManager.shared.buy()
self.rebuild()
} else {
let a = UIAlertController(title: "コインが足りません", message: "対戦するとコインがもらえます（勝利40／参加10）", preferredStyle:.alert)
a.addAction(UIAlertAction(title: "OK", style:.default))
self.present(a, animated: true)
}
}, for:.touchUpInside)
inner.addArrangedSubview(b)
}
stack.addArrangedSubview(row)
}
}
}

// MARK: - プレミアムお試し（本当の課金なし）
final class TrialStoreViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
title = "プレミアムお試し"
if navigationItem.leftBarButtonItem == nil {
navigationItem.leftBarButtonItem = UIBarButtonItem(title: "閉じる", style:.plain, target: self, action: #selector(closeSelf))
}
rebuild()
}
@objc private func closeSelf() { dismiss(animated: true)}

private func rebuild() {
stack.arrangedSubviews.forEach { $0.removeFromSuperview()}
let banner = makeLabel("⚠️ これは「お試し」画面です。値段は表示だけ。\nボタンを押しても本当のお金は一切かかりません（¥0）。通信もしません。", size: 14, bold: true, color:.yellow)
banner.backgroundColor = UIColor.black.withAlphaComponent(0.3)
banner.layer.cornerRadius = 8
banner.clipsToBounds = true
stack.addArrangedSubview(banner)
for p in trialProducts {
let owned = DataStore.shared.trialOwned.contains(p.id) && p.id != "coin1000" && p.id != "coin5000"
let row = UIView()
row.backgroundColor = UIColor.black.withAlphaComponent(0.30)
row.layer.cornerRadius = 12
let inner = UIStackView()
inner.axis = .vertical
inner.spacing = 6
inner.translatesAutoresizingMaskIntoConstraints = false
row.addSubview(inner)
NSLayoutConstraint.activate([
inner.topAnchor.constraint(equalTo: row.topAnchor, constant: 10),
inner.bottomAnchor.constraint(equalTo: row.bottomAnchor, constant: -10),
inner.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 12),
inner.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -12),
])
inner.addArrangedSubview(makeLabel("\(p.icon) \(p.name)　¥\(p.yen)", size: 16, bold: true))
inner.addArrangedSubview(makeLabel(p.detail, size: 13))
if owned {
inner.addArrangedSubview(makeLabel("✅ お試し入手済み", size: 14, color:.yellow))
} else {
let b = makeButton("お試し購入（実際は ¥0）", bg: UIColor(red: 0.55, green: 0.25, blue: 0.75, alpha: 1))
b.addAction(UIAction { _ in
let a = UIAlertController(title: "お試し購入", message: "「\(p.name)」を表示価格 ¥\(p.yen) でお試しします。\n実際のお金は一切かかりません。", preferredStyle:.alert)
a.addAction(UIAlertAction(title: "無料でお試しする", style:.default) { _ in
DataStore.shared.grantTrial(p)
SoundManager.shared.buy()
self.rebuild()
})
a.addAction(UIAlertAction(title: "キャンセル", style:.cancel))
self.present(a, animated: true)
}, for:.touchUpInside)
inner.addArrangedSubview(b)
}
stack.addArrangedSubview(row)
}
}
}

// MARK: - 記録・実績
final class StatsViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
let d = DataStore.shared
let rate = d.totalGames > 0? Int(Double(d.totalWins) / Double(d.totalGames) * 100): 0
stack.addArrangedSubview(makeLabel("📊 記録", size: 20, bold: true))
stack.addArrangedSubview(makeLabel("対戦数：\(d.totalGames) 戦\n勝利：\(d.totalWins) 勝（勝率 \(rate)%）\n出したカード：\(d.totalCardsPlayed) 枚\nUNOコール成功：\(d.totalUnoCalls) 回\n最高連勝：\(d.bestStreak)\n遊んだ種類：\(d.playedVariants.count) / 11 種類\n勝った種類：\(d.wonVariants.count) / 11 種類\nコイン：🪙 \(d.coins)", size: 15))
stack.addArrangedSubview(makeLabel("🏅 実績", size: 20, bold: true))
for a in allAchievements {
let claimed = d.claimedAchievements.contains(a.id)
let done = a.check(d)
let mark = claimed? "✅": (done? "🎁 受取可能（対戦後に自動受取）": "⬜")
stack.addArrangedSubview(makeLabel("\(mark) \(a.name)（+\(a.reward)コイン）\n　\(a.detail)", size: 14))
}
}
}

// MARK: - あそびかた
final class HowToViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
let text = """

・手札を全部なくした人が勝ち！
・自分の番に、場のカードと「同じ色」か「同じ数字・種類」のカードを1枚出せます。
・出せるカードがないときは、山札（左のカード）をタップして1枚引きます。引いたカードが出せるなら、そのまま出せます。
・残り1枚になったら、2秒以内に赤い「UNO！」ボタンを押してね。忘れると2枚引きます。


スキップ：次の人が1回休み
リバース：順番の向きが反対に（2人対戦ではスキップと同じ）
+2 / +4 など：次の人がその枚数引く
ワイルド：好きな色を宣言できる


🃏 クラシック：いつものUNO
🔀 フリップ！：フリップカードで全カードが「暗い面」に。+1が+5に、スキップが全員スキップに強化！
🌈 オールワイルド！：全部ワイルド。いつでも何でも出せる
😈 ノーマーシー：+6・+10・ルーレット・全捨て追加。手札25枚以上で脱落！積み重ね常にOK
🎯 デア！：デアカードを出されると「お題に挑戦」か「2枚引く」を選ぶ
💥 アタック：シューターが0〜4枚をランダムで当てる。当たった人は1回休み
💪 フレックス！：FLEXマークのカードは、チャージがたまっていると強い効果にできる（3ターンで回復）
🎡 スピン：スピンカードでルーレットイベント発生
🎉 パーティー！：効果を3つから選べるカード入り
🛠 リミックス：クラシックに好きな追加ルールと追加ワイルドを足せる
🐣 ジュニア：数字1〜5だけのやさしい版


積み重ね：+2/+4を出されたとき、手持ちのドロー系カードを重ねて次の人に押し付けられます
7-0：7を出すと選んだ相手と手札交換、0を出すと全員の手札がぐるっと移動
ジャンプイン：誰かが数字カードを出した直後、同じ色・同じ数字を持っている人は2.5秒以内にタップで割り込めます


🤖 CPU対戦：合計2〜7人（あなた＋CPU最大6人）
👨‍👩‍👧‍👦 みんなで交代：1台のスマホを渡し合って最大7人。番が来たらカバーを開けて遊びます


プレミアム商品は全部「お試し」です。値段は表示だけ、本当のお金は一切かかりません。
※キャラクターコラボ版などの「絵柄違い」UNOはルールがクラシックと同じため、クラシック＋テーマ変更で遊べます。
"""
let l = makeLabel(text, size: 14)
stack.addArrangedSubview(l)
}
}

// MARK: - 設定
final class SettingsViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
stack.addArrangedSubview(makeLabel("⚙️ 設定", size: 20, bold: true))
stack.addArrangedSubview(switchRow(title: "効果音", isOn: DataStore.shared.soundOn) { DataStore.shared.soundOn = $0})
stack.addArrangedSubview(switchRow(title: "BGM", isOn: DataStore.shared.musicOn) {
DataStore.shared.musicOn = $0
if $0 { SoundManager.shared.startMusic()} else { SoundManager.shared.stopMusic()}
})
stack.addArrangedSubview(switchRow(title: "振動", isOn: DataStore.shared.hapticsOn) { DataStore.shared.hapticsOn = $0})
let reset = makeButton("記録を全部消す", bg: UIColor(red: 0.75, green: 0.15, blue: 0.15, alpha: 1))
reset.addTarget(self, action: #selector(resetData), for:.touchUpInside)
stack.addArrangedSubview(reset)
stack.addArrangedSubview(makeLabel("バージョン 1.0 / iPhone 7・iOS 15対応 / 完全オフライン", size: 12, align:.center))
}

private func switchRow(title: String, isOn: Bool, onChange: @escaping (Bool) -> Void) -> UIView {
let row = UIStackView()
row.axis = .horizontal
row.spacing = 8
row.addArrangedSubview(makeLabel(title, size: 16))
let sw = UISwitch()
sw.isOn = isOn
sw.addAction(UIAction { _ in onChange(sw.isOn)}, for:.valueChanged)
row.addArrangedSubview(sw)
return row
}

@objc private func resetData() {
let a = UIAlertController(title: "記録を消しますか？", message: "コイン・記録・実績が全部消えます", preferredStyle:.alert)
a.addAction(UIAlertAction(title: "消す", style:.destructive) { _ in
if let bundle = Bundle.main.bundleIdentifier {
UserDefaults.standard.removePersistentDomain(forName: bundle)
}
self.navigationController?.dismiss(animated: true)
})
a.addAction(UIAlertAction(title: "キャンセル", style:.cancel))
present(a, animated: true)
}
}
