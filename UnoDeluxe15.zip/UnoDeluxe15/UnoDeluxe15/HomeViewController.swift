import UIKit

final class HomeViewController: UIViewController {
    private var selectedVariant: Variant = .classic
    private var variantButtons: [UIButton] = []
    private let coinsLabel = UILabel()
    private let bonusLabel = UILabel()
    private let variantDetailLabel = UILabel()
    private let modeSeg = UISegmentedControl(items: ["🤖 CPU対戦", "👨‍👩‍👧‍👦 みんなで交代"])
    private let playersLabel = UILabel()
    private var totalPlayers = 4
    private let cpuSeg = UISegmentedControl(items: ["やさしい", "ふつう", "つよい"])
    private let stackingSwitch = UISwitch()
    private let sevenZeroSwitch = UISwitch()
    private let jumpInSwitch = UISwitch()
    private let wildsLabel = UILabel()
    private var extraWilds = 4

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "ウノDX"
        buildUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refreshHeader()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyGradient(to: view, top: DataStore.shared.currentTheme.top, bottom: DataStore.shared.currentTheme.bottom)
    }

    private func refreshHeader() {
        coinsLabel.text = "🪙 \(DataStore.shared.coins)　🏆 勝利 \(DataStore.shared.totalWins) / \(DataStore.shared.totalGames) 戦"
        if DataStore.shared.dailyBonusReady {
            bonusLabel.text = "🎁 今日のボーナス +50コイン もらいました！"
            DataStore.shared.dailyBonusReady = false
        }
    }

    private func buildUI() {
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)
        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stack.topAnchor.constraint(equalTo: scroll.topAnchor, constant: 12),
            stack.bottomAnchor.constraint(equalTo: scroll.bottomAnchor, constant: -12),
            stack.leadingAnchor.constraint(equalTo: scroll.leadingAnchor, constant: 14),
            stack.trailingAnchor.constraint(equalTo: scroll.trailingAnchor, constant: -14),
            stack.widthAnchor.constraint(equalTo: scroll.widthAnchor, constant: -28),
        ])

        let titleL = makeLabel("🃏 ウノDX", size: 36, bold: true, align: .center)
        stack.addArrangedSubview(titleL)
        stack.addArrangedSubview(makeLabel("本家より盛りだくさん！ 全11種類 × 最大7人 × 完全オフライン", size: 13, bold: true, align: .center))
        coinsLabel.font = UIFont.boldSystemFont(ofSize: 15)
        coinsLabel.textColor = .yellow
        coinsLabel.textAlignment = .center
        stack.addArrangedSubview(coinsLabel)
        bonusLabel.font = UIFont.boldSystemFont(ofSize: 13)
        bonusLabel.textColor = .yellow
        bonusLabel.textAlignment = .center
        stack.addArrangedSubview(bonusLabel)

        stack.addArrangedSubview(makeLabel("🎮 遊ぶ種類を選ぶ", size: 18, bold: true))
        for v in Variant.allCases {
            let b = makeButton("\(v.icon) \(v.title)", bg: UIColor.black.withAlphaComponent(0.35), size: 16)
            b.tag = Variant.allCases.firstIndex(of: v) ?? 0
            b.contentHorizontalAlignment = .leading
            b.addTarget(self, action: #selector(variantTapped(_:)), for: .touchUpInside)
            variantButtons.append(b)
            stack.addArrangedSubview(b)
        }
        variantDetailLabel.font = UIFont.systemFont(ofSize: 13)
        variantDetailLabel.textColor = .white
        variantDetailLabel.numberOfLines = 0
        variantDetailLabel.backgroundColor = UIColor.black.withAlphaComponent(0.25)
        variantDetailLabel.layer.cornerRadius = 8
        variantDetailLabel.clipsToBounds = true
        stack.addArrangedSubview(variantDetailLabel)
        updateVariantUI()

        stack.addArrangedSubview(makeLabel("👥 あそび方", size: 18, bold: true))
        modeSeg.selectedSegmentIndex = 0
        modeSeg.addTarget(self, action: #selector(modeChanged), for: .valueChanged)
        stack.addArrangedSubview(modeSeg)

        let playersRow = UIStackView()
        playersRow.axis = .horizontal
        playersRow.spacing = 10
        let minus = makeButton("−", bg: UIColor.black.withAlphaComponent(0.4))
        minus.addTarget(self, action: #selector(playersMinus), for: .touchUpInside)
        let plus = makeButton("＋", bg: UIColor.black.withAlphaComponent(0.4))
        plus.addTarget(self, action: #selector(playersPlus), for: .touchUpInside)
        playersLabel.font = UIFont.boldSystemFont(ofSize: 16)
        playersLabel.textColor = .white
        playersLabel.textAlignment = .center
        playersRow.addArrangedSubview(minus)
        playersRow.addArrangedSubview(playersLabel)
        playersRow.addArrangedSubview(plus)
        stack.addArrangedSubview(playersRow)
        updatePlayersLabel()

        stack.addArrangedSubview(makeLabel("🤖 CPUの強さ", size: 15, bold: true))
        cpuSeg.selectedSegmentIndex = 1
        stack.addArrangedSubview(cpuSeg)

        stack.addArrangedSubview(makeLabel("🛠 追加ルール（自由にON/OFF）", size: 18, bold: true))
        stack.addArrangedSubview(ruleRow(title: "積み重ね（+2/+4の上に重ねて返す）", sw: stackingSwitch))
        stack.addArrangedSubview(ruleRow(title: "7-0ルール（7=手札交換、0=全員パス）", sw: sevenZeroSwitch))
        stack.addArrangedSubview(ruleRow(title: "ジャンプイン（同じ数字カードで割り込み）", sw: jumpInSwitch))
        stack.addArrangedSubview(makeLabel("※ノーマーシーは積み重ねが常にONです", size: 12))

        let wildRow = UIStackView()
        wildRow.axis = .horizontal
        wildRow.spacing = 10
        let wMinus = makeButton("−", bg: UIColor.black.withAlphaComponent(0.4))
        wMinus.addTarget(self, action: #selector(wildsMinus), for: .touchUpInside)
        let wPlus = makeButton("＋", bg: UIColor.black.withAlphaComponent(0.4))
        wPlus.addTarget(self, action: #selector(wildsPlus), for: .touchUpInside)
        wildsLabel.font = UIFont.boldSystemFont(ofSize: 14)
        wildsLabel.textColor = .white
        wildsLabel.textAlignment = .center
        wildRow.addArrangedSubview(wMinus)
        wildRow.addArrangedSubview(wildsLabel)
        wildRow.addArrangedSubview(wPlus)
        stack.addArrangedSubview(wildRow)
        updateWildsLabel()

        let start = makeButton("▶ ゲーム開始！", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 22)
        start.addTarget(self, action: #selector(startGame), for: .touchUpInside)
        stack.addArrangedSubview(start)

        stack.addArrangedSubview(makeLabel("📚 その他", size: 18, bold: true))
        let grid = UIStackView()
        grid.axis = .vertical
        grid.spacing = 10
        let themeB = makeButton("🎨 テーマ＆ショップ", bg: UIColor.black.withAlphaComponent(0.35))
        themeB.addTarget(self, action: #selector(openThemes), for: .touchUpInside)
        let trialB = makeButton("✨ プレミアムお試し（本当の課金なし）", bg: UIColor(red: 0.55, green: 0.25, blue: 0.75, alpha: 1))
        trialB.addTarget(self, action: #selector(openTrial), for: .touchUpInside)
        let statsB = makeButton("📊 記録・実績", bg: UIColor.black.withAlphaComponent(0.35))
        statsB.addTarget(self, action: #selector(openStats), for: .touchUpInside)
        let howB = makeButton("❓ あそびかた（全種類の説明）", bg: UIColor.black.withAlphaComponent(0.35))
        howB.addTarget(self, action: #selector(openHowTo), for: .touchUpInside)
        let setB = makeButton("⚙️ 設定", bg: UIColor.black.withAlphaComponent(0.35))
        setB.addTarget(self, action: #selector(openSettings), for: .touchUpInside)
        for b in [themeB, trialB, statsB, howB, setB] { grid.addArrangedSubview(b) }
        stack.addArrangedSubview(grid)
        stack.addArrangedSubview(makeLabel("完全オフライン対応：ネットなしで全部遊べます。本当の課金は一切ありません。", size: 11, align: .center))
        refreshHeader()
    }

    private func ruleRow(title: String, sw: UISwitch) -> UIView {
        let row = UIStackView()
        row.axis = .horizontal
        row.spacing = 8
        let l = makeLabel(title, size: 14)
        row.addArrangedSubview(l)
        row.addArrangedSubview(sw)
        return row
    }

    @objc private func variantTapped(_ b: UIButton) {
        SoundManager.shared.click()
        selectedVariant = Variant.allCases[b.tag]
        updateVariantUI()
    }

    private func updateVariantUI() {
        for (i, b) in variantButtons.enumerated() {
            let v = Variant.allCases[i]
            b.backgroundColor = v == selectedVariant ? UIColor(red: 0.90, green: 0.45, blue: 0.10, alpha: 1) : UIColor.black.withAlphaComponent(0.35)
        }
        variantDetailLabel.text = "　\(selectedVariant.detail)"
    }

    @objc private func modeChanged() { SoundManager.shared.click(); updatePlayersLabel() }
    @objc private func playersMinus() { if totalPlayers > 2 { totalPlayers -= 1 }; updatePlayersLabel() }
    @objc private func playersPlus() { if totalPlayers < 7 { totalPlayers += 1 }; updatePlayersLabel() }
    private func updatePlayersLabel() {
        if modeSeg.selectedSegmentIndex == 0 {
            playersLabel.text = "人数：合計 \(totalPlayers) 人（あなた＋CPU \(totalPlayers - 1) 人）"
        } else {
            playersLabel.text = "人数：\(totalPlayers) 人全員人間（交代で遊ぶ）"
        }
    }
    @objc private func wildsMinus() { if extraWilds > 0 { extraWilds -= 1 }; updateWildsLabel() }
    @objc private func wildsPlus() { if extraWilds < 8 { extraWilds += 1 }; updateWildsLabel() }
    private func updateWildsLabel() {
        wildsLabel.text = "リミックス用：追加ワイルド \(extraWilds) 枚"
    }

    @objc private func startGame() {
        SoundManager.shared.click()
        SoundManager.shared.startMusic()
        var cfg = GameConfig()
        cfg.variant = selectedVariant
        cfg.cpuLevel = cpuSeg.selectedSegmentIndex
        cfg.stacking = stackingSwitch.isOn
        cfg.sevenZero = sevenZeroSwitch.isOn
        cfg.jumpIn = jumpInSwitch.isOn
        if modeSeg.selectedSegmentIndex == 0 {
            let cpuNames = ["ロボ", "パンダ", "ネコ", "タヌキ", "キツネ", "ペンギン"]
            var names: [(String, Bool)] = [("あなた", true)]
            for i in 0..<(totalPlayers - 1) { names.append((cpuNames[i], false)) }
            cfg.playerNames = names
        } else {
            cfg.playerNames = (1...totalPlayers).map { ("プレイヤー\($0)", true) }
        }
        let vc = GameViewController(config: cfg, extraWilds: selectedVariant == .remix ? extraWilds : 0)
        navigationController?.pushViewController(vc, animated: true)
    }

    @objc private func openThemes() { presentNav(ThemeShopViewController(), title: "テーマ＆ショップ") }
    @objc private func openTrial() { presentNav(TrialStoreViewController(), title: "プレミアムお試し") }
    @objc private func openStats() { presentNav(StatsViewController(), title: "記録・実績") }
    @objc private func openHowTo() { presentNav(HowToViewController(), title: "あそびかた") }
    @objc private func openSettings() { presentNav(SettingsViewController(), title: "設定") }

    private func presentNav(_ vc: UIViewController, title: String) {
        SoundManager.shared.click()
        vc.title = title
        let nav = UINavigationController(rootViewController: vc)
        vc.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "閉じる", style: .plain, target: self, action: #selector(closeModal))
        present(nav, animated: true)
    }
    @objc private func closeModal() { dismiss(animated: true) }
}
