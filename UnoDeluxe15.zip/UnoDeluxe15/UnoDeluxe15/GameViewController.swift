import UIKit

final class GameViewController: UIViewController {
    let config: GameConfig
    let extraWilds: Int
    var engine: GameEngine!
    private var passMode: Bool { config.playerNames.filter { $0.isHuman }.count > 1 }

    // UI
    private let opponentsScroll = UIScrollView()
    private let opponentsStack = UIStackView()
    private let statusLabel = UILabel()
    private let bannerLabel = UILabel()
    private let discardView = CardView(frame: CGRect(x: 0, y: 0, width: 92, height: 138))
    private let deckView = CardView(frame: CGRect(x: 0, y: 0, width: 92, height: 138))
    private let infoLabel = UILabel()
    private let handScroll = UIScrollView()
    private let unoButton = UIButton(type: .system)
    private let passButton = UIButton(type: .system)
    private var coverView: UIView?

    private var inputLocked = true
    private var drewCardID: Int? = nil
    private var recorded = false
    private var cardsPlayedByHumans = 0
    private var unoSuccess = 0
    private var unoTimer: Timer?
    private var unoPlayer: Int? = nil
    private var jumpPlayer: Int? = nil
    private var jumpCardID: Int? = nil
    private var jumpTimer: Timer?
    private var lastViewerHuman: Int = -1
    private var logLines: [String] = []

    init(config: GameConfig, extraWilds: Int = 0) {
        self.config = config
        self.extraWilds = extraWilds
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = config.variant.icon + " " + config.variant.title
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "◀ やめる", style: .plain, target: self, action: #selector(quitGame))
        engine = GameEngine(config: config, extraWilds: extraWilds)
        buildUI()
        log("ゲーム開始！ \(config.variant.title)・\(config.playerNames.count)人")
        log("最初のカードは \(engine.topCard?.title(dark: false) ?? "") （\(engine.currentColor.name)）")
        refreshAll()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { self.beginTurn(first: true) }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyGradient(to: view, top: DataStore.shared.currentTheme.top, bottom: DataStore.shared.currentTheme.bottom)
    }

    private func buildUI() {
        let theme = DataStore.shared.currentTheme
        // 相手の帯
        opponentsScroll.translatesAutoresizingMaskIntoConstraints = false
        opponentsStack.axis = .horizontal
        opponentsStack.spacing = 8
        opponentsStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(opponentsScroll)
        opponentsScroll.addSubview(opponentsStack)
        // 状態ラベル
        statusLabel.numberOfLines = 3
        statusLabel.font = UIFont.systemFont(ofSize: 13)
        statusLabel.textColor = .white
        statusLabel.backgroundColor = UIColor.black.withAlphaComponent(0.30)
        statusLabel.layer.cornerRadius = 8
        statusLabel.clipsToBounds = true
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(statusLabel)
        // 中央（山札・捨て札・情報）
        let centerRow = UIStackView()
        centerRow.axis = .horizontal
        centerRow.spacing = 14
        centerRow.alignment = .center
        centerRow.translatesAutoresizingMaskIntoConstraints = false
        deckView.configureBack(emoji: theme.backEmoji)
        let deckTap = UITapGestureRecognizer(target: self, action: #selector(deckTapped))
        deckView.addGestureRecognizer(deckTap)
        discardView.translatesAutoresizingMaskIntoConstraints = false
        deckView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            discardView.widthAnchor.constraint(equalToConstant: 92), discardView.heightAnchor.constraint(equalToConstant: 138),
            deckView.widthAnchor.constraint(equalToConstant: 92), deckView.heightAnchor.constraint(equalToConstant: 138),
        ])
        infoLabel.numberOfLines = 0
        infoLabel.font = UIFont.boldSystemFont(ofSize: 15)
        infoLabel.textColor = .white
        let infoWrap = UIView()
        infoWrap.addSubview(infoLabel)
        infoLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            infoLabel.leadingAnchor.constraint(equalTo: infoWrap.leadingAnchor),
            infoLabel.trailingAnchor.constraint(equalTo: infoWrap.trailingAnchor),
            infoLabel.centerYAnchor.constraint(equalTo: infoWrap.centerYAnchor),
            infoWrap.widthAnchor.constraint(equalToConstant: 92),
        ])
        let deckWrap = UIStackView(arrangedSubviews: [deckView])
        let discardWrap = UIStackView(arrangedSubviews: [discardView])
        centerRow.addArrangedSubview(deckWrap)
        centerRow.addArrangedSubview(discardWrap)
        centerRow.addArrangedSubview(infoWrap)
        view.addSubview(centerRow)
        // バナー
        bannerLabel.textAlignment = .center
        bannerLabel.font = UIFont.boldSystemFont(ofSize: 20)
        bannerLabel.textColor = .yellow
        bannerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bannerLabel)
        // ボタン行
        unoButton.setTitle("UNO！", for: .normal)
        unoButton.setTitleColor(.white, for: .normal)
        unoButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 22)
        unoButton.backgroundColor = UIColor(red: 0.85, green: 0.16, blue: 0.16, alpha: 1)
        unoButton.layer.cornerRadius = 14
        unoButton.isHidden = true
        unoButton.addTarget(self, action: #selector(unoTapped), for: .touchUpInside)
        passButton.setTitle("パス", for: .normal)
        passButton.setTitleColor(.white, for: .normal)
        passButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        passButton.backgroundColor = UIColor.black.withAlphaComponent(0.45)
        passButton.layer.cornerRadius = 12
        passButton.isHidden = true
        passButton.addTarget(self, action: #selector(passTapped), for: .touchUpInside)
        let hintBtn = makeButton("💡ヒント", bg: UIColor.black.withAlphaComponent(0.45), size: 14)
        hintBtn.addTarget(self, action: #selector(hintTapped), for: .touchUpInside)
        let sortBtn = makeButton("↕ならびかえ", bg: UIColor.black.withAlphaComponent(0.45), size: 14)
        sortBtn.addTarget(self, action: #selector(sortTapped), for: .touchUpInside)
        let btnRow = UIStackView(arrangedSubviews: [unoButton, passButton, hintBtn, sortBtn])
        btnRow.axis = .horizontal
        btnRow.spacing = 8
        btnRow.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(btnRow)
        // 手札
        handScroll.translatesAutoresizingMaskIntoConstraints = false
        handScroll.showsHorizontalScrollIndicator = false
        view.addSubview(handScroll)

        NSLayoutConstraint.activate([
            opponentsScroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 4),
            opponentsScroll.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8),
            opponentsScroll.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            opponentsScroll.heightAnchor.constraint(equalToConstant: 64),
            opponentsStack.topAnchor.constraint(equalTo: opponentsScroll.topAnchor),
            opponentsStack.bottomAnchor.constraint(equalTo: opponentsScroll.bottomAnchor),
            opponentsStack.leadingAnchor.constraint(equalTo: opponentsScroll.leadingAnchor),
            opponentsStack.trailingAnchor.constraint(equalTo: opponentsScroll.trailingAnchor),
            opponentsStack.heightAnchor.constraint(equalToConstant: 64),

            statusLabel.topAnchor.constraint(equalTo: opponentsScroll.bottomAnchor, constant: 6),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),

            centerRow.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 8),
            centerRow.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            bannerLabel.topAnchor.constraint(equalTo: centerRow.bottomAnchor, constant: 6),
            bannerLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8),
            bannerLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),

            btnRow.topAnchor.constraint(equalTo: bannerLabel.bottomAnchor, constant: 4),
            btnRow.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            handScroll.topAnchor.constraint(equalTo: btnRow.bottomAnchor, constant: 6),
            handScroll.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 6),
            handScroll.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -6),
            handScroll.heightAnchor.constraint(equalToConstant: 118),
        ])
    }

    // MARK: - ログと表示更新
    private func log(_ s: String) {
        logLines.append(s)
        if logLines.count > 3 { logLines.removeFirst(logLines.count - 3) }
        statusLabel.text = logLines.joined(separator: "\n")
    }

    private var viewerIndex: Int {
        if passMode { return engine.current }
        return 0
    }

    private func refreshAll() {
        // 相手帯
        opponentsStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        for (i, p) in engine.players.enumerated() {
            let v = UIView()
            v.backgroundColor = i == engine.current ? UIColor.white.withAlphaComponent(0.45) : UIColor.black.withAlphaComponent(0.30)
            v.layer.cornerRadius = 10
            let l = UILabel()
            l.numberOfLines = 3
            l.textAlignment = .center
            l.font = UIFont.boldSystemFont(ofSize: 12)
            l.textColor = .white
            if p.eliminated {
                l.text = "\(p.name)\n脱落💀"
            } else {
                let unoMark = p.hand.count == 1 ? "\nUNO!" : ""
                l.text = "\(p.isHuman ? "🙂" : "🤖")\(p.name)\n🃏\(p.hand.count)枚\(unoMark)"
            }
            l.translatesAutoresizingMaskIntoConstraints = false
            v.addSubview(l)
            NSLayoutConstraint.activate([
                l.centerXAnchor.constraint(equalTo: v.centerXAnchor), l.centerYAnchor.constraint(equalTo: v.centerYAnchor),
                v.widthAnchor.constraint(equalToConstant: 86),
            ])
            opponentsStack.addArrangedSubview(v)
        }
        // 中央
        if let top = engine.topCard { discardView.configure(card: top, dark: engine.darkSide) }
        var info = "色 \(engine.currentColor.emoji)\(engine.currentColor.name)\n向き \(engine.direction == 1 ? "↻ 順番どおり" : "↺ 逆向き")\n山札 \(engine.deck.count)枚"
        if engine.pendingDraw > 0 { info += "\n⚠️\(engine.pendingDraw)枚ピンチ" }
        if engine.darkSide { info += "\n🌙暗い面" }
        infoLabel.text = info
        refreshHand()
    }

    private func refreshHand() {
        handScroll.subviews.forEach { $0.removeFromSuperview() }
        let vi = viewerIndex
        guard engine.players.indices.contains(vi) else { return }
        let hand = engine.players[vi].hand
        let cardW: CGFloat = 68, cardH: CGFloat = 104, gap: CGFloat = 6
        var x: CGFloat = 2
        let myTurn = engine.current == vi && engine.players[vi].isHuman
        for card in hand {
            let cv = CardView(frame: CGRect(x: x, y: 6, width: cardW, height: cardH))
            cv.configure(card: card, dark: engine.darkSide)
            let playable = myTurn && !inputLocked && engine.canPlay(card, byPlayer: vi)
            let isJumpCard = jumpCardID == card.id && jumpPlayer == vi
            if jumpPlayer != nil && !isJumpCard {
                cv.alpha = 0.55
            } else if myTurn && !inputLocked && !playable {
                cv.alpha = 0.55
            }
            if isJumpCard {
                cv.layer.borderColor = UIColor.yellow.cgColor
                cv.layer.borderWidth = 4
            }
            cv.tag = card.id
            let tap = UITapGestureRecognizer(target: self, action: #selector(cardTapped(_:)))
            cv.addGestureRecognizer(tap)
            handScroll.addSubview(cv)
            x += cardW + gap
        }
        handScroll.contentSize = CGSize(width: max(x, handScroll.bounds.width), height: 118)
    }

    // MARK: - 番の進行
    private func beginTurn(first: Bool = false) {
        guard !engine.roundOver else { showResult(); return }
        drewCardID = nil
        passButton.isHidden = true
        refreshAll()
        let cur = engine.current
        let player = engine.players[cur]
        if player.isHuman {
            if passMode && lastViewerHuman != cur {
                showPassCover(for: cur)
                return
            }
            lastViewerHuman = cur
            inputLocked = false
            refreshAll()
            if engine.pendingDraw > 0 {
                if engine.playableCards(for: cur).isEmpty {
                    banner("\(engine.pendingDraw)枚引くしかない！山札をタップ")
                } else {
                    banner("重ねるか、山札をタップで\(engine.pendingDraw)枚引く")
                }
            } else {
                banner("\(player.name) の番！")
            }
        } else {
            inputLocked = true
            refreshAll()
            banner("\(player.name) の番…")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) { [weak self] in
                self?.cpuStep()
            }
        }
    }

    private func showPassCover(for idx: Int) {
        let cover = UIView(frame: view.bounds)
        cover.backgroundColor = UIColor(red: 0.05, green: 0.05, blue: 0.10, alpha: 0.97)
        cover.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        let name = engine.players[idx].name
        let l = makeLabel("📱 スマホを渡してね\n\n\(name) さんの番です\n（他の人は手札を見ないでね）", size: 20, bold: true, align: .center)
        l.translatesAutoresizingMaskIntoConstraints = false
        cover.addSubview(l)
        let b = makeButton("準備OK！ 手札を見る", bg: UIColor(red: 0.10, green: 0.55, blue: 0.30, alpha: 1), size: 18)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.addTarget(self, action: #selector(dismissCover), for: .touchUpInside)
        cover.addSubview(b)
        NSLayoutConstraint.activate([
            l.centerXAnchor.constraint(equalTo: cover.centerXAnchor), l.centerYAnchor.constraint(equalTo: cover.centerYAnchor, constant: -40),
            b.centerXAnchor.constraint(equalTo: cover.centerXAnchor), b.topAnchor.constraint(equalTo: l.bottomAnchor, constant: 30),
        ])
        view.addSubview(cover)
        coverView = cover
        inputLocked = true
    }

    @objc private func dismissCover() {
        SoundManager.shared.click()
        coverView?.removeFromSuperview()
        coverView = nil
        lastViewerHuman = engine.current
        beginTurn()
    }

    private func banner(_ s: String) { bannerLabel.text = s }

    // MARK: - CPU
    private func cpuStep() {
        guard !engine.roundOver else { showResult(); return }
        let cur = engine.current
        guard !engine.players[cur].isHuman else { return }
        // 積み重ねピンチの処理
        if engine.pendingDraw > 0 {
            if engine.stackingEnabled, let move = engine.cpuChooseMove() {
                executeCPUMove(move)
            } else {
                let n = engine.pendingDraw
                engine.pendingDraw = 0
                engine.drawCards(player: cur, count: n)
                log("\(engine.players[cur].name) は \(n) 枚引いた")
                SoundManager.shared.drawCard()
                engine.current = engine.nextIndex(from: cur, steps: 1)
                refreshAll()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { self.beginTurn() }
            }
            return
        }
        if let move = engine.cpuChooseMove() {
            executeCPUMove(move)
        } else {
            // 出せるのがない→1枚引く
            let before = engine.players[cur].hand.count
            engine.drawCards(player: cur, count: 1)
            SoundManager.shared.drawCard()
            if engine.players[cur].hand.count > before {
                let drawn = engine.players[cur].hand.last!
                log("\(engine.players[cur].name) は山札から1枚引いた")
                if engine.canPlay(drawn, byPlayer: cur) {
                    refreshAll()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.55) { [weak self] in
                        guard let self = self else { return }
                        if let m = self.engine.cpuChooseMove(), m.card.id == drawn.id {
                            self.executeCPUMove(m)
                        } else {
                            self.engine.current = self.engine.nextIndex(from: cur, steps: 1)
                            self.beginTurn()
                        }
                    }
                    return
                }
            }
            engine.current = engine.nextIndex(from: cur, steps: 1)
            refreshAll()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { self.beginTurn() }
        }
    }

    private func executeCPUMove(_ move: GameEngine.CPUMove) {
        let outcome = engine.play(cardID: move.card.id, chosenColor: move.chosenColor, swapTarget: move.swapTarget, useFlex: move.useFlex, partyChoice: move.partyChoice, partyTarget: move.partyTarget)
        SoundManager.shared.playCard()
        if outcome.flipped { SoundManager.shared.flip() }
        handleOutcome(outcome, playedCard: move.card)
    }

    // MARK: - 結果処理（人間・CPU共通）
    private func handleOutcome(_ outcome: PlayOutcome, playedCard: Card) {
        for e in outcome.events { log(e) }
        refreshAll()
        if let w = outcome.winner ?? (engine.roundOver ? engine.winnerIndex : nil) {
            _ = w
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { self.showResult() }
            return
        }
        // デアの解決
        if let target = outcome.dareTarget {
            handleDare(target: target) { [weak self] in self?.afterSpecialChecks(outcome: outcome, playedCard: playedCard) }
            return
        }
        afterSpecialChecks(outcome: outcome, playedCard: playedCard)
    }

    private func afterSpecialChecks(outcome: PlayOutcome, playedCard: Card) {
        // UNOコール判定
        if let p = outcome.leftOneCardPlayer {
            handleUnoWindow(player: p) { [weak self] in self?.afterUno(outcome: outcome, playedCard: playedCard) }
            return
        }
        afterUno(outcome: outcome, playedCard: playedCard)
    }

    private func afterUno(outcome: PlayOutcome, playedCard: Card) {
        // ジャンプイン判定
        if config.jumpIn, let top = engine.topCard,
           let cand = engine.jumpInCandidate(played: top) {
            jumpPlayer = cand.player
            jumpCardID = cand.card.id
            inputLocked = false
            banner("⚡ジャンプイン！ \(engine.players[cand.player].name) は同じカードを出せる！")
            SoundManager.shared.uno()
            refreshHand()
            jumpTimer?.invalidate()
            jumpTimer = Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false) { [weak self] _ in
                guard let self = self else { return }
                self.jumpPlayer = nil; self.jumpCardID = nil
                self.beginTurn()
            }
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { self.beginTurn() }
    }

    // MARK: - UNOコール
    private func handleUnoWindow(player p: Int, done: @escaping () -> Void) {
        if engine.players[p].isHuman {
            unoPlayer = p
            unoButton.isHidden = false
            banner("⚠️ あと1枚！ UNOボタンを押して！")
            SoundManager.shared.bad()
            unoTimer?.invalidate()
            unoTimer = Timer.scheduledTimer(withTimeInterval: 2.2, repeats: false) { [weak self] _ in
                guard let self = self else { return }
                self.unoButton.isHidden = true
                self.unoPlayer = nil
                self.engine.drawCards(player: p, count: 2)
                self.log("UNOを言い忘れた！ ペナルティ2枚")
                SoundManager.shared.bad()
                self.refreshAll()
                done()
            }
            // done はボタン or タイマーどちらかで1回だけ
            unoDone = done
        } else {
            if Int.random(in: 0..<100) < 12 {
                engine.drawCards(player: p, count: 2)
                log("\(engine.players[p].name) はUNOを言い忘れた！ 2枚引く")
            } else {
                log("\(engine.players[p].name)「UNO！」")
                SoundManager.shared.uno()
            }
            refreshAll()
            done()
        }
    }
    private var unoDone: (() -> Void)? = nil

    @objc private func unoTapped() {
        guard let p = unoPlayer else { return }
        unoTimer?.invalidate()
        unoButton.isHidden = true
        unoPlayer = nil
        unoSuccess += 1
        log("\(engine.players[p].name)「UNO！」成功")
        SoundManager.shared.uno()
        SoundManager.shared.haptic()
        let d = unoDone; unoDone = nil
        d?()
    }

    // MARK: - デア
    private func handleDare(target: Int, done: @escaping () -> Void) {
        let dareText = dareList.randomElement() ?? dareList[0]
        if engine.players[target].isHuman {
            let alert = UIAlertController(title: "🎯 デアカード！", message: "\(engine.players[target].name) さん、どちらか選んでね", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "お題に挑戦する", style: .default) { _ in
                let a2 = UIAlertController(title: "お題", message: dareText, preferredStyle: .alert)
                a2.addAction(UIAlertAction(title: "できた！", style: .default) { _ in
                    for e in self.engine.resolveDare(target: target, choseDare: true, dareText: dareText) { self.log(e) }
                    self.finishDare(done: done)
                })
                a2.addAction(UIAlertAction(title: "やっぱり2枚引く", style: .cancel) { _ in
                    for e in self.engine.resolveDare(target: target, choseDare: false, dareText: dareText) { self.log(e) }
                    self.finishDare(done: done)
                })
                self.present(a2, animated: true)
            })
            alert.addAction(UIAlertAction(title: "2枚引く", style: .default) { _ in
                for e in self.engine.resolveDare(target: target, choseDare: false, dareText: dareText) { self.log(e) }
                self.finishDare(done: done)
            })
            present(alert, animated: true)
        } else {
            let chose = Bool.random()
            for e in engine.resolveDare(target: target, choseDare: chose, dareText: dareText) { log(e) }
            finishDare(done: done)
        }
    }

    private func finishDare(done: @escaping () -> Void) {
        // デアを受けた人の番は終わり（currentは受けた人になっているので次へ）
        if !engine.roundOver {
            engine.current = engine.nextIndex(from: engine.current, steps: 1)
        }
        refreshAll()
        done()
    }

    // MARK: - 人間の操作
    @objc private func cardTapped(_ g: UITapGestureRecognizer) {
        guard let v = g.view else { return }
        let cardID = v.tag
        // ジャンプイン
        if let jp = jumpPlayer, let jc = jumpCardID, cardID == jc {
            jumpTimer?.invalidate()
            jumpPlayer = nil; jumpCardID = nil
            let savedCurrent = engine.current
            engine.current = jp
            guard let card = engine.players[jp].hand.first(where: { $0.id == cardID }) else { return }
            log("⚡\(engine.players[jp].name) がジャンプイン！")
            SoundManager.shared.playCard()
            let outcome = engine.play(cardID: cardID, chosenColor: nil, swapTarget: nil, useFlex: false, partyChoice: 0, partyTarget: nil)
            _ = savedCurrent
            // ジャンプイン後は割り込んだ人の次の人から再開（play内で進んでいる）
            handleOutcomeAfterJumpIn(outcome, playedCard: card)
            return
        }
        guard !inputLocked else { return }
        let cur = engine.current
        guard engine.players[cur].isHuman, cur == viewerIndex || passMode else { return }
        guard let card = engine.players[cur].hand.first(where: { $0.id == cardID }) else { return }
        if let drew = drewCardID, cardID != drew {
            banner("引いたカードだけ出せます（パスもOK）")
            SoundManager.shared.bad()
            return
        }
        guard engine.canPlay(card, byPlayer: cur) else {
            banner("それは出せません。色・数字・種類を合わせよう")
            SoundManager.shared.bad()
            return
        }
        askChoicesAndPlay(card: card)
    }

    private func handleOutcomeAfterJumpIn(_ outcome: PlayOutcome, playedCard: Card) {
        for e in outcome.events { log(e) }
        refreshAll()
        if engine.roundOver { showResult(); return }
        if let p = outcome.leftOneCardPlayer {
            handleUnoWindow(player: p) { [weak self] in
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { self?.beginTurn() }
            }
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { self.beginTurn() }
    }

    private func askChoicesAndPlay(card: Card) {
        let cur = engine.current
        let kind = card.activeKind(dark: engine.darkSide)
        var chosenColor: CardColor? = nil
        var swapTarget: Int? = nil
        var useFlex = false
        var partyChoice = 0
        var partyTarget: Int? = nil

        func finish() {
            self.inputLocked = true
            self.drewCardID = nil
            self.passButton.isHidden = true
            if self.engine.players[cur].isHuman { self.cardsPlayedByHumans += 1 }
            let outcome = self.engine.play(cardID: card.id, chosenColor: chosenColor, swapTarget: swapTarget, useFlex: useFlex, partyChoice: partyChoice, partyTarget: partyTarget)
            SoundManager.shared.playCard()
            SoundManager.shared.haptic()
            if outcome.flipped { SoundManager.shared.flip() }
            self.handleOutcome(outcome, playedCard: card)
        }

        func colorStep(_ next: @escaping () -> Void) {
            if card.isWildKind(dark: self.engine.darkSide) && self.config.variant != .allWild {
                self.pickColor { c in chosenColor = c; next() }
            } else { next() }
        }
        func swapStep(_ next: @escaping () -> Void) {
            let need = kind == .swapHands || (kind == .number && card.activeNumber(dark: self.engine.darkSide) == 7 && self.config.sevenZero)
            if need {
                self.pickTarget(title: "手札を交換する相手") { t in swapTarget = t; next() }
            } else { next() }
        }
        func flexStep(_ next: @escaping () -> Void) {
            if card.flex && self.engine.players[cur].flexCharge {
                let a = UIAlertController(title: "💪フレックスカード", message: "どちらの効果にする？", preferredStyle: .actionSheet)
                a.addAction(UIAlertAction(title: "ふつうの効果", style: .default) { _ in useFlex = false; next() })
                a.addAction(UIAlertAction(title: "FLEX効果（強い！）", style: .default) { _ in useFlex = true; next() })
                a.addAction(UIAlertAction(title: "キャンセル", style: .cancel))
                self.presentSheet(a)
            } else { next() }
        }
        func partyStep(_ next: @escaping () -> Void) {
            if kind == .party {
                let a = UIAlertController(title: "🎉パーティー効果", message: "どれにする？", preferredStyle: .actionSheet)
                a.addAction(UIAlertAction(title: "全員（自分以外）1枚引く", style: .default) { _ in partyChoice = 0; next() })
                a.addAction(UIAlertAction(title: "指名した人が2枚引く", style: .default) { _ in
                    partyChoice = 1
                    self.pickTarget(title: "2枚引かせる相手") { t in partyTarget = t; next() }
                })
                a.addAction(UIAlertAction(title: "自分が2枚捨てる", style: .default) { _ in partyChoice = 2; next() })
                a.addAction(UIAlertAction(title: "キャンセル", style: .cancel))
                self.presentSheet(a)
            } else { next() }
        }
        colorStep { swapStep { flexStep { partyStep { finish() } } } }
    }

    private func presentSheet(_ a: UIAlertController) {
        if let pop = a.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        }
        present(a, animated: true)
    }

    private func pickColor(completion: @escaping (CardColor) -> Void) {
        let a = UIAlertController(title: "🌈 色を選ぼう", message: nil, preferredStyle: .actionSheet)
        let colors: [CardColor] = engine.darkSide ? [.pink, .teal, .orange, .purple] : [.red, .yellow, .green, .blue]
        for c in colors {
            a.addAction(UIAlertAction(title: "\(c.emoji) \(c.name)", style: .default) { _ in completion(c) })
        }
        a.addAction(UIAlertAction(title: "キャンセル", style: .cancel))
        presentSheet(a)
    }

    private func pickTarget(title: String, completion: @escaping (Int) -> Void) {
        let a = UIAlertController(title: title, message: nil, preferredStyle: .actionSheet)
        for idx in engine.activePlayers where idx != engine.current {
            a.addAction(UIAlertAction(title: "\(engine.players[idx].name)（\(engine.players[idx].hand.count)枚）", style: .default) { _ in completion(idx) })
        }
        a.addAction(UIAlertAction(title: "キャンセル", style: .cancel))
        presentSheet(a)
    }

    @objc private func deckTapped() {
        guard !inputLocked else { return }
        let cur = engine.current
        guard engine.players[cur].isHuman else { return }
        if engine.pendingDraw > 0 {
            let n = engine.pendingDraw
            engine.pendingDraw = 0
            engine.drawCards(player: cur, count: n)
            log("\(engine.players[cur].name) は \(n) 枚引いた")
            SoundManager.shared.drawCard()
            inputLocked = true
            engine.current = engine.nextIndex(from: cur, steps: 1)
            refreshAll()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { self.beginTurn() }
            return
        }
        guard drewCardID == nil else { return }
        let before = engine.players[cur].hand.count
        engine.drawCards(player: cur, count: 1)
        SoundManager.shared.drawCard()
        refreshAll()
        guard engine.players[cur].hand.count > before, let drawn = engine.players[cur].hand.last else {
            engine.current = engine.nextIndex(from: cur, steps: 1)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { self.beginTurn() }
            return
        }
        if engine.canPlay(drawn, byPlayer: cur) {
            drewCardID = drawn.id
            passButton.isHidden = false
            banner("「\(drawn.title(dark: engine.darkSide))」を引いた！そのまま出せる")
            refreshHand()
        } else {
            log("引いたカードは出せないのでパス")
            inputLocked = true
            engine.current = engine.nextIndex(from: cur, steps: 1)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { self.beginTurn() }
        }
    }

    @objc private func passTapped() {
        guard !inputLocked, drewCardID != nil else { return }
        drewCardID = nil
        passButton.isHidden = true
        inputLocked = true
        engine.current = engine.nextIndex(from: engine.current, steps: 1)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { self.beginTurn() }
    }

    @objc private func hintTapped() {
        let cur = engine.current
        guard engine.players[cur].isHuman else { return }
        let playable = engine.playableCards(for: cur)
        if engine.pendingDraw > 0 && !engine.stackingEnabled {
            banner("ヒント：\(engine.pendingDraw)枚引くしかありません")
        } else if playable.isEmpty {
            banner("ヒント：出せるカードなし。山札を引こう")
        } else {
            banner("ヒント：出せるのは \(playable.count) 枚（明るく表示中）")
        }
        SoundManager.shared.click()
        refreshHand()
    }

    @objc private func sortTapped() {
        let vi = viewerIndex
        engine.players[vi].hand.sort {
            if $0.activeColor(dark: engine.darkSide).rawValue != $1.activeColor(dark: engine.darkSide).rawValue {
                return $0.activeColor(dark: engine.darkSide).rawValue < $1.activeColor(dark: engine.darkSide).rawValue
            }
            return $0.activeNumber(dark: engine.darkSide) < $1.activeNumber(dark: engine.darkSide)
        }
        SoundManager.shared.click()
        refreshHand()
    }

    @objc private func quitGame() {
        let a = UIAlertController(title: "やめますか？", message: "対戦をやめてホームに戻ります", preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "やめる", style: .destructive) { _ in
            self.navigationController?.popViewController(animated: true)
        })
        a.addAction(UIAlertAction(title: "つづける", style: .cancel))
        present(a, animated: true)
    }

    // MARK: - 結果
    private func showResult() {
        guard !recorded else { return }
        recorded = true
        inputLocked = true
        guard let w = engine.winnerIndex else { return }
        let winner = engine.players[w]
        let score = engine.winnerScore()
        DataStore.shared.recordGame(variant: config.variant, playerCount: config.playerNames.count,
                                     humanWon: winner.isHuman, cardsPlayed: cardsPlayedByHumans, unoCalls: unoSuccess)
        let gained = DataStore.shared.claimAchievements()
        SoundManager.shared.win()
        confetti()
        var msg = "勝者：\(winner.name)（+\(score)点）\n\n"
        for (i, p) in engine.players.enumerated() {
            msg += "\(i + 1). \(p.name)：残り\(p.hand.count)枚\(p.eliminated ? "（脱落）" : "")\n"
        }
        msg += "\nごほうびコインをもらいました"
        if gained > 0 { msg += "\n🏅実績ボーナス +\(gained)コイン！" }
        let a = UIAlertController(title: "🏆 \(winner.name) の勝ち！", message: msg, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "もう1ラウンド", style: .default) { _ in
            let vc = GameViewController(config: self.config, extraWilds: self.extraWilds)
            self.navigationController?.pushViewController(vc, animated: true)
            if let nav = self.navigationController, nav.viewControllers.count > 2 {
                nav.viewControllers.remove(at: nav.viewControllers.count - 2)
            }
        })
        a.addAction(UIAlertAction(title: "ホームへ", style: .default) { _ in
            self.navigationController?.popViewController(animated: true)
        })
        present(a, animated: true)
    }

    private func confetti() {
        let colors: [UIColor] = [.red, .yellow, .green, .blue, .orange, .purple]
        for i in 0..<36 {
            let v = UIView(frame: CGRect(x: CGFloat.random(in: 0..<view.bounds.width), y: -20, width: 9, height: 14))
            v.backgroundColor = colors[i % colors.count]
            v.layer.cornerRadius = 2
            view.addSubview(v)
            UIView.animate(withDuration: Double.random(in: 1.2...2.2), delay: Double.random(in: 0...0.5), options: [.curveEaseIn], animations: {
                v.frame.origin.y = self.view.bounds.height + 30
                v.frame.origin.x += CGFloat.random(in: -40...40)
                v.transform = CGAffineTransform(rotationAngle: CGFloat.random(in: 0...6))
            }, completion: { _ in v.removeFromSuperview() })
        }
    }
}
