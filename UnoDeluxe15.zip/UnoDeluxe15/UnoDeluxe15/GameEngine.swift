import Foundation

// MARK: - 設定
struct GameConfig {
    var variant: Variant = .classic
    var playerNames: [(name: String, isHuman: Bool)] = []
    var cpuLevel: Int = 1           // 0=やさしい 1=ふつう 2=つよい
    var stacking: Bool = false      // 積み重ね（+2/+4の上に重ねられる）
    var sevenZero: Bool = false     // 7で交換・0で全員パス
    var jumpIn: Bool = false        // ジャンプイン（同じ数字カードで割り込み）
    var initialHand: Int = 7
}

// MARK: - プレイヤー
final class Player {
    let name: String
    let isHuman: Bool
    var hand: [Card] = []
    var eliminated: Bool = false
    var flexCharge: Bool = true
    var flexTurns: Int = 0
    init(name: String, isHuman: Bool) {
        self.name = name
        self.isHuman = isHuman
    }
}

// MARK: - カードを出した結果
struct PlayOutcome {
    var events: [String] = []
    var leftOneCardPlayer: Int? = nil   // UNOコールが必要な人
    var dareTarget: Int? = nil          // デアの選択が必要な人（人間なら画面で選ぶ）
    var winner: Int? = nil
    var flipped: Bool = false
}

// MARK: - デッキ作成
final class DeckBuilder {
    static func build(variant: Variant, extraWilds: Int = 0) -> [Card] {
        var cards: [Card] = []
        var nextID = 1
        func add(_ color: CardColor, _ kind: CardKind, _ number: Int = 0, count: Int = 1, flex: Bool = false) {
            for _ in 0..<count {
                cards.append(Card(id: nextID, color: color, kind: kind, number: number, flex: flex))
                nextID += 1
            }
        }
        let mainColors: [CardColor] = [.red, .yellow, .green, .blue]
        switch variant {
        case .classic, .remix:
            for c in mainColors {
                add(c, .number, 0, count: 1)
                for n in 1...9 { add(c, .number, n, count: 2) }
                add(c, .skip, count: 2); add(c, .reverse, count: 2); add(c, .draw, 2, count: 2)
            }
            add(.wild, .wild, count: 4); add(.wild, .wildDraw, 4, count: 4)
            if variant == .remix { add(.wild, .wild, count: extraWilds) }
        case .junior:
            for c in mainColors {
                for n in 1...5 { add(c, .number, n, count: 2) }
                add(c, .skip, count: 1); add(c, .reverse, count: 1); add(c, .draw, 1, count: 1)
            }
            add(.wild, .wild, count: 4)
        case .flip:
            for c in mainColors {
                add(c, .number, 0, count: 1)
                for n in 1...9 { add(c, .number, n, count: 2) }
                add(c, .draw, 1, count: 2); add(c, .skip, count: 2); add(c, .reverse, count: 2); add(c, .flip, count: 2)
            }
            add(.wild, .wild, count: 4); add(.wild, .wildDraw, 2, count: 4)
        case .allWild:
            // 全部ワイルド色。数字もアクションもいつでも出せる
            for n in 1...9 { add(.wild, .number, n, count: 4) }
            add(.wild, .number, 0, count: 4)
            add(.wild, .skip, count: 8); add(.wild, .reverse, count: 8)
            add(.wild, .draw, 2, count: 8); add(.wild, .wildDraw, 4, count: 4)
            add(.wild, .swapHands, count: 4)
        case .noMercy:
            for c in mainColors {
                add(c, .number, 0, count: 1)
                for n in 1...9 { add(c, .number, n, count: 2) }
                add(c, .skip, count: 2); add(c, .reverse, count: 2); add(c, .draw, 2, count: 2)
                add(c, .skipAll, count: 1); add(c, .discardAll, count: 1); add(c, .flip, count: 1)
            }
            add(.wild, .wild, count: 4); add(.wild, .wildDraw, 4, count: 4)
            add(.wild, .wildDraw, 6, count: 4); add(.wild, .wildDraw, 10, count: 2)
            add(.wild, .roulette, count: 4)
        case .dare:
            for c in mainColors {
                add(c, .number, 0, count: 1)
                for n in 1...9 { add(c, .number, n, count: 2) }
                add(c, .skip, count: 2); add(c, .reverse, count: 2); add(c, .draw, 2, count: 2)
            }
            add(.wild, .wild, count: 4); add(.wild, .wildDraw, 4, count: 2); add(.wild, .dare, count: 6)
        case .attack:
            for c in mainColors {
                add(c, .number, 0, count: 1)
                for n in 1...9 { add(c, .number, n, count: 2) }
                add(c, .skip, count: 2); add(c, .reverse, count: 2); add(c, .attack, count: 3)
            }
            add(.wild, .wild, count: 4); add(.wild, .wildDraw, 4, count: 4)
        case .flex:
            for c in mainColors {
                add(c, .number, 0, count: 1)
                for n in 1...9 { add(c, .number, n, count: 2) }
                add(c, .skip, count: 2); add(c, .reverse, count: 2)
                add(c, .draw, 2, count: 1); add(c, .draw, 2, count: 1, flex: true)
                add(c, .skip, count: 1, flex: true)
            }
            add(.wild, .wild, count: 4); add(.wild, .wildDraw, 4, count: 2); add(.wild, .wild, count: 2, flex: true)
        case .spin:
            for c in mainColors {
                add(c, .number, 0, count: 1)
                for n in 1...9 { add(c, .number, n, count: 2) }
                add(c, .skip, count: 2); add(c, .reverse, count: 2); add(c, .draw, 2, count: 2); add(c, .spin, count: 2)
            }
            add(.wild, .wild, count: 4); add(.wild, .wildDraw, 4, count: 4)
        case .party:
            for c in mainColors {
                add(c, .number, 0, count: 1)
                for n in 1...9 { add(c, .number, n, count: 2) }
                add(c, .skip, count: 2); add(c, .reverse, count: 2); add(c, .draw, 2, count: 2)
            }
            add(.wild, .wild, count: 4); add(.wild, .wildDraw, 4, count: 2); add(.wild, .party, count: 6)
        }
        return cards.shuffled()
    }
}

// MARK: - ゲーム本体
final class GameEngine {
    let config: GameConfig
    var players: [Player] = []
    var deck: [Card] = []
    var discard: [Card] = []
    var currentColor: CardColor = .red
    var direction: Int = 1
    var current: Int = 0
    var pendingDraw: Int = 0
    var darkSide: Bool = false
    var roundOver: Bool = false
    var winnerIndex: Int? = nil
    var extraTurnForCurrent: Bool = false  // スピン「もう1枚出せる」等
    var lastPlayedBy: Int = -1

    var stackingEnabled: Bool {
        if config.variant == .noMercy { return true }
        return config.stacking
    }
    var mercyEnabled: Bool { config.variant == .noMercy }

    init(config: GameConfig, extraWilds: Int = 0) {
        self.config = config
        self.players = config.playerNames.map { Player(name: $0.name, isHuman: $0.isHuman) }
        self.deck = DeckBuilder.build(variant: config.variant, extraWilds: extraWilds)
        let handCount = config.variant == .junior ? 5 : config.initialHand
        for _ in 0..<handCount {
            for p in players { if let c = drawFromDeck() { p.hand.append(c) } }
        }
        // 最初のカード（数字が出るまでめくり直す。ただし最大20回）
        var top: Card? = nil
        for _ in 0..<20 {
            guard let c = drawFromDeck() else { break }
            top = c
            if c.activeKind(dark: false) == .number { break }
            deck.append(c); deck.shuffle()
            top = nil
        }
        if let t = top {
            discard.append(t)
            currentColor = t.activeColor(dark: false)
        }
    }

    var topCard: Card? { discard.last }
    var activePlayers: [Int] { players.indices.filter { !players[$0].eliminated } }

    func nextIndex(from: Int, steps: Int) -> Int {
        var idx = from
        var moved = 0
        while moved < steps {
            idx = (idx + direction + players.count) % players.count
            if !players[idx].eliminated { moved += 1 }
        }
        return idx
    }
    func targetIndex() -> Int { nextIndex(from: current, steps: 1) }

    private func drawFromDeck() -> Card? {
        if deck.isEmpty {
            // 捨て札を山札に戻す（一番上だけ残す）
            guard discard.count > 1 else { return nil }
            let top = discard.removeLast()
            deck = discard.shuffled()
            discard = [top]
        }
        return deck.popLast()
    }

    @discardableResult
    func drawCards(player idx: Int, count: Int) -> Int {
        var got = 0
        for _ in 0..<count {
            if let c = drawFromDeck() { players[idx].hand.append(c); got += 1 }
        }
        checkMercy(player: idx)
        return got
    }

    func checkMercy(player idx: Int) {
        guard mercyEnabled, !roundOver else { return }
        if players[idx].hand.count >= 25 && !players[idx].eliminated {
            players[idx].eliminated = true
            players[idx].hand = []
            if activePlayers.count == 1 {
                winnerIndex = activePlayers[0]
                roundOver = true
            }
        }
    }

    // MARK: 出せるかどうか
    func canPlay(_ card: Card, byPlayer idx: Int) -> Bool {
        guard !roundOver else { return false }
        if pendingDraw > 0 {
            guard stackingEnabled else { return false }
            let k = card.activeKind(dark: darkSide)
            return k == .draw || k == .wildDraw
        }
        if config.variant == .allWild { return true }
        guard let top = topCard else { return true }
        if card.isWildKind(dark: darkSide) { return true }
        if card.activeColor(dark: darkSide) == currentColor { return true }
        let ck = card.activeKind(dark: darkSide)
        let tk = top.activeKind(dark: darkSide)
        if ck == tk {
            if ck == .number { return card.activeNumber(dark: darkSide) == top.activeNumber(dark: darkSide) }
            return true
        }
        return false
    }

    func playableCards(for idx: Int) -> [Card] {
        players[idx].hand.filter { canPlay($0, byPlayer: idx) }
    }

    // MARK: カードを出す
    // chosenColor: ワイルド系の色指定 / swapTarget: 7・手札交換の相手 / useFlex: フレックス効果 / partyChoice: 0=全員+1 1=指名+2 2=自分2枚捨て
    func play(cardID: Int, chosenColor: CardColor?, swapTarget: Int?, useFlex: Bool, partyChoice: Int, partyTarget: Int?) -> PlayOutcome {
        var out = PlayOutcome()
        let pIdx = current
        guard let handIdx = players[pIdx].hand.firstIndex(where: { $0.id == cardID }) else { return out }
        lastPlayedBy = pIdx
        let card = players[pIdx].hand.remove(at: handIdx)
        discard.append(card)
        let kind = card.activeKind(dark: darkSide)
        let num = card.activeNumber(dark: darkSide)
        let name = players[pIdx].name
        out.events.append("\(name) が \(card.title(dark: darkSide)) を出した")

        // フレックスチャージ消費
        if card.flex && useFlex { players[pIdx].flexCharge = false; players[pIdx].flexTurns = 0 }

        // 色の決定
        if card.isWildKind(dark: darkSide) {
            currentColor = chosenColor ?? cpuBestColor(for: pIdx)
            out.events.append("色は \(currentColor.emoji)\(currentColor.name) に決定")
        } else {
            currentColor = card.activeColor(dark: darkSide)
        }

        var advanceSteps = 1
        var skipAdvance = false

        switch kind {
        case .number:
            if config.sevenZero && num == 0 {
                // 全員の手札が進行方向に1つずれる
                let hands = activePlayers.map { players[$0].hand }
                for (i, idx) in activePlayers.enumerated() {
                    let src = direction == 1 ? (i - 1 + hands.count) % hands.count : (i + 1) % hands.count
                    players[idx].hand = hands[src]
                }
                out.events.append("0の効果！ 全員の手札がぐるっと移動")
            } else if config.sevenZero && num == 7, let t = swapTarget, t != pIdx, !players[t].eliminated {
                let tmpHand = players[pIdx].hand; players[pIdx].hand = players[t].hand; players[t].hand = tmpHand
                out.events.append("7の効果！ \(players[t].name) と手札を交換")
            }
        case .skip:
            if useFlex && card.flex {
                advanceSteps = 0; skipAdvance = true
                out.events.append("FLEXスキップ！ 全員スキップしてもう一度出せる")
            } else {
                advanceSteps = 2
                out.events.append("\(players[targetIndex()].name) はスキップ")
            }
        case .reverse:
            direction *= -1
            out.events.append("リバース！ 進む向きが反対に")
            advanceSteps = activePlayers.count == 2 ? 2 : 1
        case .draw, .wildDraw:
            var amount = num
            if useFlex && card.flex { amount *= 2; out.events.append("FLEX効果！ 枚数が2倍") }
            pendingDraw += amount
            let t = targetIndex()
            out.events.append("\(players[t].name) は \(pendingDraw) 枚引くピンチ！（積み重ね\(stackingEnabled ? "OK" : "不可")）")
            advanceSteps = 1
        case .flip:
            darkSide.toggle()
            out.flipped = true
            out.events.append(darkSide ? "フリップ！ 暗い面になった（効果が強化）" : "フリップ！ 明るい面に戻った")
        case .skipAll:
            advanceSteps = 0; skipAdvance = true
            out.events.append("全員スキップ！ もう一度出せる")
        case .dare:
            let t = targetIndex()
            out.dareTarget = t
            advanceSteps = 1
        case .attack:
            let t = targetIndex()
            let hits = [0, 0, 2, 2, 2, 4].randomElement() ?? 2
            if hits > 0 {
                drawCards(player: t, count: hits)
                out.events.append("💥シューター発射！ \(players[t].name) に \(hits) 枚ヒット")
            } else {
                out.events.append("💥シューター発射！ …スカッ（0枚）")
            }
            advanceSteps = 2  // 当たった人は1回休み扱い
        case .spin:
            let ev = Int.random(in: 0..<spinEvents.count)
            out.events.append("🎡スピン： \(spinEvents[ev])")
            applySpin(event: ev, player: pIdx, events: &out.events)
        case .party:
            applyParty(choice: partyChoice, player: pIdx, target: partyTarget, events: &out.events)
        case .swapHands:
            if let t = swapTarget, t != pIdx, !players[t].eliminated {
                let tmpHand2 = players[pIdx].hand; players[pIdx].hand = players[t].hand; players[t].hand = tmpHand2
                out.events.append("\(players[t].name) と手札を交換！")
            }
        case .discardAll:
            let col = card.activeColor(dark: darkSide)
            let extra = players[pIdx].hand.filter { $0.activeColor(dark: darkSide) == col }
            for c in extra {
                if let i = players[pIdx].hand.firstIndex(of: c) {
                    players[pIdx].hand.remove(at: i); discard.append(c)
                }
            }
            if !extra.isEmpty { out.events.append("同じ色のカード \(extra.count) 枚も全部捨てた！") }
        case .roulette:
            let t = targetIndex()
            let col = currentColor
            var drawn = 0
            while drawn < 15 {
                guard let c = drawFromDeck() else { break }
                players[t].hand.append(c); drawn += 1
                if c.activeColor(dark: darkSide) == col { break }
            }
            checkMercy(player: t)
            out.events.append("🎲ルーレット： \(players[t].name) は \(col.name) が出るまで \(drawn) 枚引いた")
            advanceSteps = 2
        case .wild:
            if useFlex && card.flex {
                let t = targetIndex()
                pendingDraw += 2
                out.events.append("FLEXワイルド！ ついでに次の人は2枚引くピンチ")
            }
        }

        // フレックスチャージ回復（自分の番が3回過ぎたら）
        for p in players where !p.flexCharge {
            p.flexTurns += 1
            if p.flexTurns >= 3 { p.flexCharge = true; p.flexTurns = 0 }
        }

        // 勝利判定
        if players[pIdx].hand.isEmpty {
            winnerIndex = pIdx
            roundOver = true
            out.winner = pIdx
            out.events.append("🏆 \(name) のあがり！")
            return out
        }
        if players[pIdx].hand.count == 1 { out.leftOneCardPlayer = pIdx }

        // 脱落で勝者が決まった場合
        if roundOver {
            out.winner = winnerIndex
            return out
        }

        if extraTurnForCurrent {
            skipAdvance = true
            extraTurnForCurrent = false
        }
        if !skipAdvance {
            current = nextIndex(from: current, steps: advanceSteps)
        }
        return out
    }

    private func applySpin(event: Int, player pIdx: Int, events: inout [String]) {
        switch event {
        case 0:
            for idx in activePlayers where idx != pIdx { drawCards(player: idx, count: 1) }
            events.append("自分以外が全員1枚引いた")
        case 1:
            let left = nextIndex(from: pIdx, steps: 1)
            let tmpHand3 = players[pIdx].hand; players[pIdx].hand = players[left].hand; players[left].hand = tmpHand3
            events.append("\(players[left].name) と手札を交換した")
        case 2:
            let col = currentColor
            let targets = players[pIdx].hand.filter { $0.activeColor(dark: darkSide) == col }
            for c in targets {
                if let i = players[pIdx].hand.firstIndex(of: c) {
                    players[pIdx].hand.remove(at: i); discard.append(c)
                }
            }
            events.append("\(col.name) のカード \(targets.count) 枚を捨てた")
        case 3:
            drawCards(player: pIdx, count: 2)
            events.append("自分が2枚引いた…")
        case 4:
            var n = 0
            while n < 2 && players[pIdx].hand.count > 1 {
                let c = players[pIdx].hand.remove(at: Int.random(in: 0..<players[pIdx].hand.count))
                discard.append(c); n += 1
            }
            events.append("ランダムに \(n) 枚捨てた")
        case 5:
            extraTurnForCurrent = true
            events.append("もう1枚出せる！")
        default: break
        }
    }

    private func applyParty(choice: Int, player pIdx: Int, target: Int?, events: inout [String]) {
        switch choice {
        case 0:
            for idx in activePlayers where idx != pIdx { drawCards(player: idx, count: 1) }
            events.append("🎉全員（自分以外）が1枚引いた")
        case 1:
            if let t = target, t != pIdx, !players[t].eliminated {
                drawCards(player: t, count: 2)
                events.append("🎉\(players[t].name) が2枚引いた")
            }
        case 2:
            var n = 0
            while n < 2 && players[pIdx].hand.count > 1 {
                let c = players[pIdx].hand.remove(at: Int.random(in: 0..<players[pIdx].hand.count))
                discard.append(c); n += 1
            }
            events.append("🎉自分は \(n) 枚捨てた")
        default: break
        }
    }

    // デアの解決（targetが人間なら画面の選択、CPUなら呼び出し側で決めて渡す）
    func resolveDare(target: Int, choseDare: Bool, dareText: String) -> [String] {
        if choseDare {
            return ["🎯 \(players[target].name) はお題「\(dareText)」に挑戦！ 引かなくてOK"]
        } else {
            drawCards(player: target, count: 2)
            return ["\(players[target].name) は2枚引いた"]
        }
    }

    // ジャンプイン候補（数字カードを出した直後、別の人間が同じカードを持っているか）
    func jumpInCandidate(played: Card) -> (player: Int, card: Card)? {
        guard config.jumpIn, played.activeKind(dark: darkSide) == .number else { return nil }
        for idx in players.indices where idx != current && idx != lastPlayedBy && players[idx].isHuman && !players[idx].eliminated {
            if let c = players[idx].hand.first(where: {
                $0.activeKind(dark: darkSide) == .number &&
                $0.activeNumber(dark: darkSide) == played.activeNumber(dark: darkSide) &&
                $0.activeColor(dark: darkSide) == played.activeColor(dark: darkSide)
            }) {
                return (idx, c)
            }
        }
        return nil
    }

    // MARK: CPUの考え
    func cpuBestColor(for idx: Int) -> CardColor {
        var counts: [CardColor: Int] = [:]
        for c in players[idx].hand {
            let col = c.activeColor(dark: darkSide)
            if col != .wild { counts[col, default: 0] += 1 }
        }
        if config.variant == .allWild { return [.red, .yellow, .green, .blue].randomElement() ?? .red }
        let pool: [CardColor] = darkSide ? [.pink, .teal, .orange, .purple] : [.red, .yellow, .green, .blue]
        return counts.max(by: { $0.value < $1.value })?.key ?? pool.randomElement() ?? .red
    }

    struct CPUMove {
        var card: Card
        var chosenColor: CardColor? = nil
        var swapTarget: Int? = nil
        var useFlex: Bool = false
        var partyChoice: Int = 0
        var partyTarget: Int? = nil
    }

    func cpuChooseMove() -> CPUMove? {
        let idx = current
        let options = playableCards(for: idx)
        guard !options.isEmpty else { return nil }
        var picked: Card
        if config.cpuLevel == 0 && Int.random(in: 0..<10) < 5 {
            picked = options.randomElement()!
        } else {
            // 強い順：重いカード・攻撃系を優先、ワイルドは温存気味
            func score(_ c: Card) -> Int {
                var s = c.points
                let k = c.activeKind(dark: darkSide)
                switch k {
                case .draw, .wildDraw: s += 30
                case .skip, .skipAll, .attack: s += 22
                case .reverse: s += 12
                case .discardAll: s += 40
                case .wild: s -= 15
                default: break
                }
                // 次の人が少ないときは攻撃系をさらに優先
                let t = targetIndex()
                if players[t].hand.count <= 2 && (k == .draw || k == .wildDraw || k == .skip || k == .attack) { s += 30 }
                return s
            }
            picked = options.max(by: { score($0) < score($1) }) ?? options[0]
        }
        var move = CPUMove(card: picked)
        if picked.isWildKind(dark: darkSide) { move.chosenColor = cpuBestColor(for: idx) }
        let k = picked.activeKind(dark: darkSide)
        if (k == .number && picked.activeNumber(dark: darkSide) == 7 && config.sevenZero) || k == .swapHands {
            // 一番手札が少ない相手と交換するのが得…ではなく自分の手札が多いとき交換が得。相手は「一番少ない人」を選ぶ
            let others = activePlayers.filter { $0 != idx }
            move.swapTarget = others.min(by: { players[$0].hand.count < players[$1].hand.count }) ?? others.first
        }
        if picked.flex && players[idx].flexCharge && config.cpuLevel >= 1 {
            move.useFlex = Int.random(in: 0..<10) < 6
        }
        if k == .party {
            move.partyChoice = [0, 1, 2].randomElement() ?? 0
            if move.partyChoice == 1 {
                let others = activePlayers.filter { $0 != idx }
                move.partyTarget = others.min(by: { players[$0].hand.count < players[$1].hand.count }) ?? others.first
            }
        }
        return move
    }

    // 得点計算（勝者は他の全員の残り点数をゲット）
    func winnerScore() -> Int {
        guard let w = winnerIndex else { return 0 }
        return players.indices.filter { $0 != w }.reduce(0) { $0 + players[$1].hand.reduce(0) { $0 + $1.points } }
    }
}
