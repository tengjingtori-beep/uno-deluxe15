import UIKit

// MARK: - カードの色
enum CardColor: Int, CaseIterable {
    case red, yellow, green, blue, pink, teal, orange, purple, wild

    var uiColor: UIColor {
        switch self {
        case .red: return UIColor(red: 0.85, green: 0.16, blue: 0.16, alpha: 1)
        case .yellow: return UIColor(red: 0.96, green: 0.75, blue: 0.05, alpha: 1)
        case .green: return UIColor(red: 0.10, green: 0.62, blue: 0.25, alpha: 1)
        case .blue: return UIColor(red: 0.10, green: 0.35, blue: 0.85, alpha: 1)
        case .pink: return UIColor(red: 0.90, green: 0.30, blue: 0.65, alpha: 1)
        case .teal: return UIColor(red: 0.05, green: 0.65, blue: 0.65, alpha: 1)
        case .orange: return UIColor(red: 0.95, green: 0.50, blue: 0.08, alpha: 1)
        case .purple: return UIColor(red: 0.50, green: 0.20, blue: 0.80, alpha: 1)
        case .wild: return UIColor(red: 0.12, green: 0.12, blue: 0.14, alpha: 1)
        }
    }
    var name: String {
        switch self {
        case .red: return "赤"
        case .yellow: return "黄"
        case .green: return "緑"
        case .blue: return "青"
        case .pink: return "ピンク"
        case .teal: return "水色"
        case .orange: return "オレンジ"
        case .purple: return "紫"
        case .wild: return "ワイルド"
        }
    }
    var emoji: String {
        switch self {
        case .red: return "🟥"
        case .yellow: return "🟨"
        case .green: return "🟩"
        case .blue: return "🟦"
        case .pink: return "🩷"
        case .teal: return "🩵"
        case .orange: return "🟧"
        case .purple: return "🟪"
        case .wild: return "🌈"
        }
    }
    // フリップ：明るい面→暗い面の色対応
    var darkPair: CardColor {
        switch self {
        case .red: return .pink
        case .yellow: return .orange
        case .green: return .teal
        case .blue: return .purple
        default: return self
        }
    }
    var lightPair: CardColor {
        switch self {
        case .pink: return .red
        case .orange: return .yellow
        case .teal: return .green
        case .purple: return .blue
        default: return self
        }
    }
}

// MARK: - カードの種類
// draw / wildDraw は number に「引く枚数」が入る
enum CardKind: String {
    case number, skip, reverse, draw, wild, wildDraw, flip, skipAll
    case dare, attack, spin, party, swapHands, discardAll, roulette
}

struct Card: Equatable {
    let id: Int
    // 明るい面
    let color: CardColor
    let kind: CardKind
    let number: Int
    // 暗い面（フリップ用。ふつうは明るい面と同じ）
    let darkColor: CardColor
    let darkKind: CardKind
    let darkNumber: Int
    // フレックスカードかどうか
    let flex: Bool

    init(id: Int, color: CardColor, kind: CardKind, number: Int = 0, flex: Bool = false) {
        self.id = id
        self.color = color
        self.kind = kind
        self.number = number
        self.flex = flex
        // 暗い面の自動変換（フリップ用）
        self.darkColor = (color == .wild) ? .wild : color.darkPair
        switch kind {
        case .draw:
            self.darkKind = (number == 1) ? .draw : kind
            self.darkNumber = (number == 1) ? 5 : number
        case .skip:
            self.darkKind = .skipAll
            self.darkNumber = 0
        case .wildDraw:
            self.darkKind = .roulette
            self.darkNumber = 0
        default:
            self.darkKind = kind
            self.darkNumber = number
        }
    }

    func activeColor(dark: Bool) -> CardColor { dark ? darkColor : color }
    func activeKind(dark: Bool) -> CardKind { dark ? darkKind : kind }
    func activeNumber(dark: Bool) -> Int { dark ? darkNumber : number }

    func isWildKind(dark: Bool) -> Bool {
        switch activeKind(dark: dark) {
        case .wild, .wildDraw, .dare, .party, .swapHands, .roulette: return true
        default: return activeColor(dark: dark) == .wild
        }
    }

    func title(dark: Bool) -> String {
        let k = activeKind(dark: dark)
        let n = activeNumber(dark: dark)
        switch k {
        case .number: return "\(n)"
        case .skip: return "スキップ"
        case .reverse: return "リバース"
        case .draw: return "+\(n)"
        case .wild: return "ワイルド"
        case .wildDraw: return "ワイルド+\(n)"
        case .flip: return "フリップ"
        case .skipAll: return "全員スキップ"
        case .dare: return "デア!"
        case .attack: return "アタック"
        case .spin: return "スピン"
        case .party: return "パーティー"
        case .swapHands: return "手札交換"
        case .discardAll: return "全捨て"
        case .roulette: return "ルーレット"
        }
    }
    func symbol(dark: Bool) -> String {
        let k = activeKind(dark: dark)
        let n = activeNumber(dark: dark)
        switch k {
        case .number: return "\(n)"
        case .skip: return "🚫"
        case .reverse: return "🔄"
        case .draw: return "+\(n)"
        case .wild: return "🌈"
        case .wildDraw: return "+\(n)"
        case .flip: return "🔀"
        case .skipAll: return "⏭"
        case .dare: return "🎯"
        case .attack: return "💥"
        case .spin: return "🎡"
        case .party: return "🎉"
        case .swapHands: return "🔁"
        case .discardAll: return "🗑"
        case .roulette: return "🎲"
        }
    }
    var points: Int {
        switch kind {
        case .number: return number
        case .wild, .wildDraw, .roulette, .swapHands: return 50
        case .draw: return number >= 6 ? 40 : 20
        default: return 20
        }
    }
}

// MARK: - 遊べる種類（現実のUNOシリーズのルール違いを全部入り）
enum Variant: String, CaseIterable {
    case classic, flip, allWild, noMercy, dare, attack, flex, spin, party, remix, junior

    var title: String {
        switch self {
        case .classic: return "クラシック"
        case .flip: return "フリップ！"
        case .allWild: return "オールワイルド！"
        case .noMercy: return "ノーマーシー（容赦なし）"
        case .dare: return "デア！"
        case .attack: return "アタック"
        case .flex: return "フレックス！"
        case .spin: return "スピン"
        case .party: return "パーティー！"
        case .remix: return "リミックス（自由カスタム）"
        case .junior: return "ジュニア（やさしい）"
        }
    }
    var icon: String {
        switch self {
        case .classic: return "🃏"
        case .flip: return "🔀"
        case .allWild: return "🌈"
        case .noMercy: return "😈"
        case .dare: return "🎯"
        case .attack: return "💥"
        case .flex: return "💪"
        case .spin: return "🎡"
        case .party: return "🎉"
        case .remix: return "🛠"
        case .junior: return "🐣"
        }
    }
    var detail: String {
        switch self {
        case .classic: return "いつものUNO。数字・スキップ・リバース・+2・ワイルド+4"
        case .flip: return "フリップカードで全カードが暗い面に！ +1→+5、スキップ→全員スキップに強化"
        case .allWild: return "全部のカードがワイルド！いつでも出せる大暴れルール"
        case .noMercy: return "+6・+10・ルーレット追加。手札25枚以上で脱落！積み重ね標準ON"
        case .dare: return "デアカード：次の人は「お題に挑戦」か「2枚引く」かを選ぶ"
        case .attack: return "アタックカード：シューター発射で0〜4枚がランダムで当たる"
        case .flex: return "フレックスカード：ためたパワーで強い方の効果が使える"
        case .spin: return "スピンカード：ルーレットで全員引き・交換・捨て札イベント発生"
        case .party: return "パーティーカード：全員引き・指名引き・捨て札の選べる効果"
        case .remix: return "クラシック＋好きな追加ルールを全部自分で選べる版"
        case .junior: return "数字は1〜5だけ・枚数少なめ。小さい子・練習用"
        }
    }
}

// MARK: - テーマ（カードと台の見た目）
struct CardTheme: Identifiable {
    let id: String
    let name: String
    let coinPrice: Int
    let premiumYen: Int  // 0 = プレミアムではない
    let top: UIColor
    let bottom: UIColor
    let backEmoji: String
    let detail: String
}

let allThemes: [CardTheme] = [
    CardTheme(id: "classic", name: "クラシック", coinPrice: 0, premiumYen: 0,
              top: UIColor(red: 0.10, green: 0.35, blue: 0.20, alpha: 1), bottom: UIColor(red: 0.05, green: 0.20, blue: 0.12, alpha: 1),
              backEmoji: "🃏", detail: "緑の台・いつもの見た目"),
    CardTheme(id: "ocean", name: "海", coinPrice: 100, premiumYen: 0,
              top: UIColor(red: 0.05, green: 0.40, blue: 0.70, alpha: 1), bottom: UIColor(red: 0.10, green: 0.65, blue: 0.85, alpha: 1),
              backEmoji: "🌊", detail: "青い海の台"),
    CardTheme(id: "sunset", name: "夕焼け", coinPrice: 150, premiumYen: 0,
              top: UIColor(red: 0.90, green: 0.40, blue: 0.20, alpha: 1), bottom: UIColor(red: 0.98, green: 0.70, blue: 0.30, alpha: 1),
              backEmoji: "🌇", detail: "オレンジの夕方"),
    CardTheme(id: "sakura", name: "桜・和風", coinPrice: 200, premiumYen: 0,
              top: UIColor(red: 0.85, green: 0.45, blue: 0.60, alpha: 1), bottom: UIColor(red: 0.98, green: 0.80, blue: 0.88, alpha: 1),
              backEmoji: "🌸", detail: "ピンクの和風"),
    CardTheme(id: "night", name: "星空", coinPrice: 250, premiumYen: 0,
              top: UIColor(red: 0.03, green: 0.05, blue: 0.20, alpha: 1), bottom: UIColor(red: 0.20, green: 0.15, blue: 0.45, alpha: 1),
              backEmoji: "⭐️", detail: "真夜中の星空"),
    CardTheme(id: "neon", name: "ネオン", coinPrice: 350, premiumYen: 0,
              top: UIColor(red: 0.15, green: 0.02, blue: 0.25, alpha: 1), bottom: UIColor(red: 0.60, green: 0.05, blue: 0.55, alpha: 1),
              backEmoji: "💜", detail: "光るネオン風"),
    CardTheme(id: "gold", name: "ゴールド", coinPrice: 0, premiumYen: 480,
              top: UIColor(red: 0.55, green: 0.40, blue: 0.05, alpha: 1), bottom: UIColor(red: 0.95, green: 0.78, blue: 0.20, alpha: 1),
              backEmoji: "👑", detail: "プレミアム：金ピカ"),
    CardTheme(id: "rainbow", name: "レインボー", coinPrice: 0, premiumYen: 680,
              top: UIColor(red: 0.60, green: 0.25, blue: 0.85, alpha: 1), bottom: UIColor(red: 0.20, green: 0.75, blue: 0.85, alpha: 1),
              backEmoji: "🌈", detail: "プレミアム：虹色"),
]

// MARK: - お試し課金アイテム（表示だけ。本当のお金は一切かかりません）
struct TrialProduct: Identifiable {
    let id: String
    let name: String
    let yen: Int
    let detail: String
    let icon: String
}

let trialProducts: [TrialProduct] = [
    TrialProduct(id: "gold", name: "ゴールド テーマ", yen: 480, detail: "金ピカのプレミアムテーマ", icon: "👑"),
    TrialProduct(id: "rainbow", name: "レインボー テーマ", yen: 680, detail: "虹色のプレミアムテーマ", icon: "🌈"),
    TrialProduct(id: "coin1000", name: "コイン 1000枚", yen: 320, detail: "テーマ購入に使えるコイン", icon: "🪙"),
    TrialProduct(id: "coin5000", name: "コイン 5000枚", yen: 980, detail: "コインがどっさり", icon: "💰"),
    TrialProduct(id: "allthemes", name: "全テーマ解放パス", yen: 980, detail: "有料テーマを全部解放", icon: "🔓"),
    TrialProduct(id: "allpack", name: "全部入りパック", yen: 1480, detail: "全テーマ＋コイン5000枚", icon: "🎁"),
]

// MARK: - デアのお題（家族で笑える安全なお題だけ）
let dareList: [String] = [
    "変な顔を5秒キープ！",
    "ネコの鳴き真似をして！",
    "片足で10秒立って！",
    "自分の名前を歌いながら言って！",
    "ロボットの動きで歩いて！",
    "一番好きな食べ物を全力で紹介して！",
    "ペンギン歩きで一周して！",
    "宇宙人のあいさつをして！",
    "モノマネを1つして！",
    "両手を上げてジャンプ3回！",
    "魚が泳ぐ真似をして！",
    "拍手を一番速く10回して！",
]

// MARK: - スピンのイベント
let spinEvents: [String] = [
    "全員1枚引く", "手札を左の人と交換", "自分の色カードを全部捨てる",
    "2枚引く", "ランダムに2枚捨てる", "もう1枚カードを出せる",
]
