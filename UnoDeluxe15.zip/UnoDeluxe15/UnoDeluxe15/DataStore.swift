import Foundation

// MARK: - 保存データ（全部オフライン・端末の中だけ）
final class DataStore {
    static let shared = DataStore()
    private let d = UserDefaults.standard

    var coins: Int { get { d.integer(forKey: "coins") } set { d.set(newValue, forKey: "coins") } }
    var ownedThemes: [String] { get { d.stringArray(forKey: "ownedThemes") ?? ["classic"] } set { d.set(newValue, forKey: "ownedThemes") } }
    var selectedTheme: String { get { d.string(forKey: "selectedTheme") ?? "classic" } set { d.set(newValue, forKey: "selectedTheme") } }
    var trialOwned: [String] { get { d.stringArray(forKey: "trialOwned") ?? [] } set { d.set(newValue, forKey: "trialOwned") } }
    var totalGames: Int { get { d.integer(forKey: "totalGames") } set { d.set(newValue, forKey: "totalGames") } }
    var totalWins: Int { get { d.integer(forKey: "totalWins") } set { d.set(newValue, forKey: "totalWins") } }
    var totalCardsPlayed: Int { get { d.integer(forKey: "totalCardsPlayed") } set { d.set(newValue, forKey: "totalCardsPlayed") } }
    var totalUnoCalls: Int { get { d.integer(forKey: "totalUnoCalls") } set { d.set(newValue, forKey: "totalUnoCalls") } }
    var bestStreak: Int { get { d.integer(forKey: "bestStreak") } set { d.set(newValue, forKey: "bestStreak") } }
    var currentStreak: Int { get { d.integer(forKey: "currentStreak") } set { d.set(newValue, forKey: "currentStreak") } }
    var playedVariants: [String] { get { d.stringArray(forKey: "playedVariants") ?? [] } set { d.set(newValue, forKey: "playedVariants") } }
    var wonVariants: [String] { get { d.stringArray(forKey: "wonVariants") ?? [] } set { d.set(newValue, forKey: "wonVariants") } }
    var played7: Bool { get { d.bool(forKey: "played7") } set { d.set(newValue, forKey: "played7") } }
    var claimedAchievements: [String] { get { d.stringArray(forKey: "claimed") ?? [] } set { d.set(newValue, forKey: "claimed") } }
    var soundOn: Bool { get { d.object(forKey: "soundOn") == nil ? true : d.bool(forKey: "soundOn") } set { d.set(newValue, forKey: "soundOn") } }
    var musicOn: Bool { get { d.bool(forKey: "musicOn") } set { d.set(newValue, forKey: "musicOn") } }
    var hapticsOn: Bool { get { d.object(forKey: "hapticsOn") == nil ? true : d.bool(forKey: "hapticsOn") } set { d.set(newValue, forKey: "hapticsOn") } }

    init() {
        if d.object(forKey: "coins") == nil { d.set(300, forKey: "coins") }
        checkDailyBonus()
    }

    var currentTheme: CardTheme { allThemes.first { $0.id == selectedTheme } ?? allThemes[0] }

    private func checkDailyBonus() {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        let today = f.string(from: Date())
        if d.string(forKey: "lastDay") != today {
            d.set(today, forKey: "lastDay")
            coins += 50
            d.set(true, forKey: "dailyBonusReady")
        }
    }
    var dailyBonusReady: Bool { get { d.bool(forKey: "dailyBonusReady") } set { d.set(newValue, forKey: "dailyBonusReady") } }

    func grantTrial(_ p: TrialProduct) {
        if !trialOwned.contains(p.id) { trialOwned.append(p.id) }
        switch p.id {
        case "gold":
            if !ownedThemes.contains("gold") { ownedThemes.append("gold") }
        case "rainbow":
            if !ownedThemes.contains("rainbow") { ownedThemes.append("rainbow") }
        case "coin1000":
            coins += 1000
        case "coin5000":
            coins += 5000
        case "allthemes":
            for t in allThemes where !ownedThemes.contains(t.id) { ownedThemes.append(t.id) }
        case "allpack":
            for t in allThemes where !ownedThemes.contains(t.id) { ownedThemes.append(t.id) }
            coins += 5000
            for t in ["gold", "rainbow", "allthemes"] where !trialOwned.contains(t) { trialOwned.append(t) }
        default: break
        }
    }

    func recordGame(variant: Variant, playerCount: Int, humanWon: Bool, cardsPlayed: Int, unoCalls: Int) {
        totalGames += 1
        totalCardsPlayed += cardsPlayed
        totalUnoCalls += unoCalls
        if !playedVariants.contains(variant.rawValue) { playedVariants.append(variant.rawValue) }
        if playerCount >= 7 { played7 = true }
        if humanWon {
            totalWins += 1
            currentStreak += 1
            if currentStreak > bestStreak { bestStreak = currentStreak }
            if !wonVariants.contains(variant.rawValue) { wonVariants.append(variant.rawValue) }
            coins += 40
        } else {
            currentStreak = 0
            coins += 10
        }
    }
}

// MARK: - 実績
struct Achievement: Identifiable {
    let id: String
    let name: String
    let detail: String
    let reward: Int
    let check: (DataStore) -> Bool
}

let allAchievements: [Achievement] = [
    Achievement(id: "win1", name: "初勝利！", detail: "はじめて1位になる", reward: 50) { $0.totalWins >= 1 },
    Achievement(id: "win10", name: "常勝", detail: "合計10勝する", reward: 150) { $0.totalWins >= 10 },
    Achievement(id: "games20", name: "常連さん", detail: "合計20ゲーム遊ぶ", reward: 80) { $0.totalGames >= 20 },
    Achievement(id: "cards300", name: "カード職人", detail: "合計300枚カードを出す", reward: 100) { $0.totalCardsPlayed >= 300 },
    Achievement(id: "uno20", name: "ウノ名人", detail: "UNOコールを20回成功", reward: 100) { $0.totalUnoCalls >= 20 },
    Achievement(id: "streak3", name: "3連勝", detail: "3連勝する", reward: 120) { $0.bestStreak >= 3 },
    Achievement(id: "allvariants", name: "全種類制覇（遊ぶ）", detail: "全11種類で遊ぶ", reward: 200) { $0.playedVariants.count >= 11 },
    Achievement(id: "winvariants5", name: "5種制覇（勝つ）", detail: "5種類で勝利する", reward: 200) { $0.wonVariants.count >= 5 },
    Achievement(id: "seven", name: "7人対戦", detail: "7人で対戦する", reward: 80) { $0.played7 },
    Achievement(id: "nomercy", name: "容赦なし勝利", detail: "ノーマーシーで勝つ", reward: 150) { $0.wonVariants.contains("noMercy") },
]

extension DataStore {
    // 未受取で達成済みの実績を受け取り、もらえたコイン数を返す
    func claimAchievements() -> Int {
        var gained = 0
        for a in allAchievements where a.check(self) && !claimedAchievements.contains(a.id) {
            claimedAchievements.append(a.id)
            coins += a.reward
            gained += a.reward
        }
        return gained
    }
}
