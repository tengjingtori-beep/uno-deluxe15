import UIKit

// カードの見た目（全部コードで描く。画像ファイル不要）
final class CardView: UIView {
    private let oval = UIView()
    private let centerLabel = UILabel()
    private let cornerLabel = UILabel()
    private let flexBadge = UILabel()
    private let backLabel = UILabel()
    private var card: Card?
    private var dark: Bool = false

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private func setup() {
        layer.cornerRadius = 10
        layer.borderWidth = 2
        layer.borderColor = UIColor.white.cgColor
        clipsToBounds = true
        oval.backgroundColor = .white
        oval.isUserInteractionEnabled = false
        addSubview(oval)
        centerLabel.textAlignment = .center
        centerLabel.adjustsFontSizeToFitWidth = true
        centerLabel.minimumScaleFactor = 0.4
        centerLabel.isUserInteractionEnabled = false
        addSubview(centerLabel)
        cornerLabel.font = UIFont.boldSystemFont(ofSize: 11)
        cornerLabel.textColor = .white
        cornerLabel.isUserInteractionEnabled = false
        addSubview(cornerLabel)
        flexBadge.text = "FLEX"
        flexBadge.font = UIFont.boldSystemFont(ofSize: 8)
        flexBadge.textColor = .black
        flexBadge.backgroundColor = UIColor(red: 1.0, green: 0.85, blue: 0.1, alpha: 1)
        flexBadge.textAlignment = .center
        flexBadge.layer.cornerRadius = 4
        flexBadge.clipsToBounds = true
        flexBadge.isUserInteractionEnabled = false
        addSubview(flexBadge)
        backLabel.textAlignment = .center
        backLabel.isUserInteractionEnabled = false
        addSubview(backLabel)
    }

    func configure(card: Card, dark: Bool) {
        self.card = card
        self.dark = dark
        backLabel.isHidden = true
        oval.isHidden = false
        centerLabel.isHidden = false
        cornerLabel.isHidden = false
        let col = card.activeColor(dark: dark)
        if col == .wild {
            backgroundColor = UIColor(red: 0.10, green: 0.10, blue: 0.12, alpha: 1)
        } else {
            backgroundColor = col.uiColor
        }
        centerLabel.text = card.symbol(dark: dark)
        let isNumber = card.activeKind(dark: dark) == .number
        centerLabel.font = UIFont.boldSystemFont(ofSize: isNumber ? 44 : 30)
        centerLabel.textColor = col == .wild ? UIColor.black : col.uiColor
        if card.activeKind(dark: dark) == .wild || card.activeKind(dark: dark) == .wildDraw || card.activeKind(dark: dark) == .roulette {
            centerLabel.textColor = UIColor(red: 0.85, green: 0.16, blue: 0.16, alpha: 1)
        }
        cornerLabel.text = card.title(dark: dark)
        flexBadge.isHidden = !card.flex
        setNeedsLayout()
    }

    func configureBack(emoji: String) {
        self.card = nil
        backgroundColor = UIColor(red: 0.55, green: 0.08, blue: 0.12, alpha: 1)
        oval.isHidden = true
        centerLabel.isHidden = true
        cornerLabel.isHidden = true
        flexBadge.isHidden = true
        backLabel.isHidden = false
        backLabel.text = "\(emoji)\nウノDX"
        backLabel.numberOfLines = 2
        backLabel.font = UIFont.boldSystemFont(ofSize: 15)
        backLabel.textColor = .white
        setNeedsLayout()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let w = bounds.width, h = bounds.height
        // 白い楕円を斜めに
        oval.frame = CGRect(x: w * 0.10, y: h * 0.22, width: w * 0.80, height: h * 0.56)
        oval.layer.cornerRadius = oval.frame.height / 2
        oval.transform = CGAffineTransform(rotationAngle: -0.35)
        centerLabel.frame = CGRect(x: 2, y: h * 0.24, width: w - 4, height: h * 0.52)
        cornerLabel.frame = CGRect(x: 5, y: 3, width: w - 10, height: 14)
        flexBadge.frame = CGRect(x: w - 36, y: h - 16, width: 32, height: 12)
        backLabel.frame = CGRect(x: 2, y: h * 0.28, width: w - 4, height: h * 0.5)
    }
}
